from flask import Flask, render_template, redirect, url_for, session, flash, request, send_file
from flask_session import Session
from config import Config
from db import init_db, get_user_uploads, get_latest_analysis
from auth import auth
from ml.pipeline import run_pipeline

import io
import json
import datetime

app = Flask(__name__)
app.config.from_object(Config)
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_FILE_DIR'] = './flask_sessions'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True
Session(app)

app.register_blueprint(auth)

with app.app_context():
    init_db()


# ==============================================
# Main Routes
# ==============================================

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('upload'))
    return redirect(url_for('auth.login'))


@app.route('/upload')
def upload():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    return render_template('upload.html')


@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    result = session.get('result', None)
    return render_template('dashboard.html', result=result)


@app.route('/history')
def history():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    uploads = get_user_uploads(session['user_id'])
    for u in uploads:
        u['analysis'] = get_latest_analysis(u['id'])
    return render_template('history.html', uploads=uploads)


@app.route('/analyze', methods=['POST'])
def analyze():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))

    # ═══════════════════════════════════════════════════════════════════════
    # VALIDATION: Year is required
    # ═══════════════════════════════════════════════════════════════════════
    year = request.form.get("year", "").strip()

    if not year:
        flash('Year is required — please enter a forecast year (e.g. 2025)', 'error')
        return redirect(url_for('upload'))

    try:
        year_int = int(year)
        if year_int < 2000 or year_int > 2100:
            flash('Invalid year — please enter a year between 2000 and 2100', 'error')
            return redirect(url_for('upload'))
    except ValueError:
        flash('Invalid year — please enter a valid number (e.g. 2025)', 'error')
        return redirect(url_for('upload'))

    # ═══════════════════════════════════════════════════════════════════════
    # FIXED: Only Year and Region filters
    # REMOVED: product, category, month
    # ═══════════════════════════════════════════════════════════════════════
    filters = {
        "year": year,
        "region": request.form.get("region", ""),
    }

    result = run_pipeline(
        file=request.files.get('file'),
        user_id=session['user_id'],
        filters=filters,
    )

    if not result['success']:
        flash(result['error'], 'error')
        return redirect(url_for('upload'))

    session['result'] = result
    session['upload_id'] = result['upload_id']
    return redirect(url_for('dashboard'))


# ==============================================
# Export Routes — Excel & PDF
# ==============================================

@app.route('/export/excel')
def export_excel():
    """Export results as Excel with professional dark dashboard style"""
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))

    result = session.get('result')
    if not result:
        flash('No results to export — upload a file first', 'error')
        return redirect(url_for('dashboard'))

    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

        wb = openpyxl.Workbook()

        # Color palette & style
        INDIGO = "6366F1"
        GREEN = "22D3A0"
        AMBER = "F59E0B"
        DARK = "111320"
        DARK2 = "161925"
        WHITE = "E2E4F0"
        MUTED = "5A6080"

        def hdr_style(cell, bg=INDIGO, fg=WHITE, bold=True, size=11):
            cell.font = Font(bold=bold, color=fg, size=size, name='Calibri')
            cell.fill = PatternFill("solid", fgColor=bg)
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

        thin = Side(style='thin', color="1E2235")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)

        # Sheet 1 — Executive Summary
        ws1 = wb.active
        ws1.title = "Executive Summary"
        ws1.column_dimensions['A'].width = 28
        ws1.column_dimensions['B'].width = 22
        ws1.column_dimensions['C'].width = 22
        ws1.column_dimensions['D'].width = 18
        ws1.row_dimensions[1].height = 40
        ws1.row_dimensions[2].height = 25

        # Main title
        ws1.merge_cells('A1:D1')
        title_cell = ws1['A1']
        title_cell.value = "Sales Analyzer — Results & Forecast Report"
        title_cell.font = Font(bold=True, color=WHITE, size=16, name='Calibri')
        title_cell.fill = PatternFill("solid", fgColor=DARK)
        title_cell.alignment = Alignment(horizontal='center', vertical='center')

        # Report date
        ws1.merge_cells('A2:D2')
        date_cell = ws1['A2']
        date_cell.value = f"Report Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}"
        date_cell.font = Font(color=MUTED, size=10, name='Calibri')
        date_cell.fill = PatternFill("solid", fgColor=DARK2)
        date_cell.alignment = Alignment(horizontal='center', vertical='center')

        # 4 Main KPIs for ML Pipeline
        kpi_data = [
            ("Predicted Revenue", f"{result.get('revenue_pred', 0):,.0f} $", INDIGO),
            ("Predicted Profit", f"{result.get('profit_pred', 0):,.0f} $", GREEN),
            ("Predicted Profit Margin", f"{result.get('profit_margin', 0):.1f}%", AMBER),
            ("Model Accuracy R²", f"{result.get('metrics', {}).get('revenue', {}).get('r2', 0):.4f}", "38BDF8"),
        ]

        row = 4
        ws1.merge_cells(f'A{row}:D{row}')
        hdr = ws1[f'A{row}']
        hdr.value = "KPI — Key Performance Indicators"
        hdr_style(hdr, bg=DARK, size=12)
        ws1.row_dimensions[row].height = 28
        row += 1

        for label, value, color in kpi_data:
            ws1.row_dimensions[row].height = 30
            c_lbl = ws1.cell(row=row, column=1, value=label)
            c_val = ws1.cell(row=row, column=2, value=value)
            c_lbl.font = Font(bold=True, color=WHITE, size=11, name='Calibri')
            c_lbl.fill = PatternFill("solid", fgColor=DARK2)
            c_lbl.alignment = Alignment(horizontal='left', vertical='center')
            c_val.font = Font(bold=True, color=color, size=13, name='Calibri')
            c_val.fill = PatternFill("solid", fgColor=DARK2)
            c_val.alignment = Alignment(horizontal='center', vertical='center')
            ws1.merge_cells(f'C{row}:D{row}')
            row += 1

        # Cross Validation Results for model stability
        metrics = result.get('metrics', {})
        rev_m = metrics.get('revenue', {})
        cv_r2 = rev_m.get('cv_r2', 0)
        cv_std = rev_m.get('cv_std', 0)

        row += 1
        ws1.merge_cells(f'A{row}:D{row}')
        cv_hdr = ws1[f'A{row}']
        cv_hdr.value = "Cross Validation Results (Model Stability Assessment)"
        hdr_style(cv_hdr, bg=DARK, size=12)
        ws1.row_dimensions[row].height = 28
        row += 1

        for label, value in [
            ("CV R² Revenue (mean)", f"{cv_r2:.4f}"),
            ("CV R² Revenue (std)", f"± {cv_std:.4f}"),
            ("RMSE Revenue", f"{rev_m.get('rmse', 0):,.0f}"),
            ("MAE Revenue", f"{rev_m.get('mae', 0):,.0f}"),
        ]:
            ws1.row_dimensions[row].height = 24
            c1 = ws1.cell(row=row, column=1, value=label)
            c2 = ws1.cell(row=row, column=2, value=value)
            c1.font = Font(color=WHITE, size=10, name='Calibri')
            c1.fill = PatternFill("solid", fgColor=DARK2)
            c1.alignment = Alignment(horizontal='left', vertical='center')
            c2.font = Font(bold=True, color=WHITE, size=10, name='Calibri')
            c2.fill = PatternFill("solid", fgColor=DARK2)
            c2.alignment = Alignment(horizontal='center', vertical='center')
            row += 1

        # Confidence intervals for financial management 95%
        ci = result.get('confidence_interval', {})
        ci_rev = ci.get('revenue', {})
        ci_pro = ci.get('profit', {})

        row += 1
        ws1.merge_cells(f'A{row}:D{row}')
        ci_hdr = ws1[f'A{row}']
        ci_hdr.value = "Statistical Confidence Interval 95%"
        hdr_style(ci_hdr, bg=DARK, size=12)
        ws1.row_dimensions[row].height = 28
        row += 1

        for label, value in [
            ("Revenue — Minimum Guaranteed", f"{ci_rev.get('lower', 0):,.0f}"),
            ("Revenue — Actual Forecast", f"{ci_rev.get('predicted', 0):,.0f}"),
            ("Revenue — Maximum Optimistic", f"{ci_rev.get('upper', 0):,.0f}"),
            ("Profit  — Minimum Guaranteed", f"{ci_pro.get('lower', 0):,.0f}"),
            ("Profit  — Actual Forecast", f"{ci_pro.get('predicted', 0):,.0f}"),
            ("Profit  — Maximum Optimistic", f"{ci_pro.get('upper', 0):,.0f}"),
        ]:
            ws1.row_dimensions[row].height = 24
            c1 = ws1.cell(row=row, column=1, value=label)
            c2 = ws1.cell(row=row, column=2, value=value)
            c1.font = Font(color=WHITE, size=10, name='Calibri')
            c1.fill = PatternFill("solid", fgColor=DARK2)
            c1.alignment = Alignment(horizontal='left', vertical='center')
            c2.font = Font(bold=True, color=WHITE, size=10, name='Calibri')
            c2.fill = PatternFill("solid", fgColor=DARK2)
            c2.alignment = Alignment(horizontal='center', vertical='center')
            row += 1

        # Sheet 2 — Monthly Recursive Forecast
        ws2 = wb.create_sheet("Monthly Forecast")
        for col, width in [('A', 18), ('B', 20), ('C', 20), ('D', 16)]:
            ws2.column_dimensions[col].width = width
        ws2.row_dimensions[1].height = 32

        ws2.merge_cells('A1:D1')
        t = ws2['A1']
        t.value = "Future Monthly Forecasts Table"
        hdr_style(t, size=13)

        headers = ["Time Period", "Predicted Revenue", "Predicted Profit", "Profit Margin %"]
        for i, h in enumerate(headers, 1):
            c = ws2.cell(row=2, column=i, value=h)
            hdr_style(c, bg=DARK2)
            ws2.row_dimensions[2].height = 24

        monthly = result.get('monthly_forecast', [])
        for r_idx, m in enumerate(monthly, 3):
            ws2.row_dimensions[r_idx].height = 22
            vals = [
                m.get('month_label', ''),
                m.get('revenue', 0),
                m.get('profit', 0),
                m.get('margin', 0),
            ]
            fills = [DARK2, DARK2, DARK2, DARK2]
            colors = [WHITE, INDIGO, GREEN, AMBER]
            for c_idx, (v, bg, fg) in enumerate(zip(vals, fills, colors), 1):
                cell = ws2.cell(row=r_idx, column=c_idx, value=v)
                cell.fill = PatternFill("solid", fgColor=bg)
                cell.font = Font(color=fg, size=10, name='Calibri', bold=(c_idx > 1))
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.border = border

        # Sheet 3 — Product Performance
        ws3 = wb.create_sheet("Product Performance")
        for col, width in [('A', 20), ('B', 20), ('C', 20), ('D', 16), ('E', 14)]:
            ws3.column_dimensions[col].width = width
        ws3.row_dimensions[1].height = 32

        ws3.merge_cells('A1:E1')
        t3 = ws3['A1']
        t3.value = "Product Classification & Evaluation"
        hdr_style(t3, size=13)

        headers3 = ["Product", "Total Revenue", "Total Profit", "Total Quantity", "Performance Rating"]
        for i, h in enumerate(headers3, 1):
            c = ws3.cell(row=2, column=i, value=h)
            hdr_style(c, bg=DARK2)
            ws3.row_dimensions[2].height = 24

        label_colors = {"Top": GREEN, "Average": AMBER, "Low": "F87171"}
        products = result.get('products_summary', [])
        for r_idx, p in enumerate(products, 3):
            ws3.row_dimensions[r_idx].height = 22
            vals = [p.get('name', '').title(), p.get('revenue', 0), p.get('profit', 0), p.get('quantity', 0),
                    p.get('label', 'Unknown')]
            for c_idx, v in enumerate(vals, 1):
                cell = ws3.cell(row=r_idx, column=c_idx, value=v)
                cell.fill = PatternFill("solid", fgColor=DARK2)
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.border = border
                fg = label_colors.get(v, WHITE) if c_idx == 5 else WHITE
                cell.font = Font(color=fg, size=10, name='Calibri', bold=(c_idx in [1, 5]))

        # Sheet 4 — What-If Market Scenarios
        ws4 = wb.create_sheet("What-If Scenarios")
        for col, width in [('A', 24), ('B', 22), ('C', 22), ('D', 14)]:
            ws4.column_dimensions[col].width = width
        ws4.row_dimensions[1].height = 32

        ws4.merge_cells('A1:D1')
        t4 = ws4['A1']
        t4.value = "What-If Scenario Analysis — Market Simulation"
        hdr_style(t4, size=13)

        headers4 = ["Target Scenario", "Predicted Revenue", "Predicted Profit", "Sales Volume Change"]
        for i, h in enumerate(headers4, 1):
            c = ws4.cell(row=2, column=i, value=h)
            hdr_style(c, bg=DARK2)
            ws4.row_dimensions[2].height = 24

        sc_colors = {20: GREEN, 0: INDIGO, -15: AMBER}
        for r_idx, sc in enumerate(result.get('what_if_scenarios', []), 3):
            ws4.row_dimensions[r_idx].height = 26
            chg = sc.get('change_pct', 0)
            color = sc_colors.get(chg, WHITE)
            for c_idx, v in enumerate([
                sc.get('name', ''),
                sc.get('revenue', 0),
                sc.get('profit', 0),
                f"{'+' if chg > 0 else ''}{chg}%",
            ], 1):
                cell = ws4.cell(row=r_idx, column=c_idx, value=v)
                cell.fill = PatternFill("solid", fgColor=DARK2)
                cell.font = Font(color=color if c_idx > 1 else WHITE, bold=True, size=11, name='Calibri')
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.border = border

        # Save to RAM temporarily
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)

        filename = f"sales_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=filename
        )

    except Exception as e:
        import traceback
        traceback.print_exc()
        flash(f'Error creating Excel file: {str(e)}', 'error')
        return redirect(url_for('dashboard'))


# ═══════════════════════════════════════════════════════════════════════
# FIXED: PDF Export — Dark Luxury Theme (Premium)
# ═══════════════════════════════════════════════════════════════════════
@app.route('/export/pdf')
def export_pdf():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))

    result = session.get('result')
    if not result:
        flash('No results to export — run analysis first', 'error')
        return redirect(url_for('dashboard'))

    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont

        def plain(text):
            return str(text)

        output = io.BytesIO()
        doc = SimpleDocTemplate(
            output, pagesize=A4,
            rightMargin=2 * cm, leftMargin=2 * cm,
            topMargin=2 * cm, bottomMargin=2 * cm
        )

        # ═══════════════════════════════════════════════════════════════════════
        # DARK LUXURY THEME — Premium Colors
        # ═══════════════════════════════════════════════════════════════════════
        BG_MAIN = colors.HexColor('#0b0d14')
        BG_CARD = colors.HexColor('#111320')
        BG_CARD_2 = colors.HexColor('#161925')
        BG_HEADER = colors.HexColor('#1a1d2e')
        INDIGO = colors.HexColor('#6366f1')
        INDIGO_GLOW = colors.HexColor('#4f52d4')
        GREEN = colors.HexColor('#22d3a0')
        AMBER = colors.HexColor('#f59e0b')
        RED = colors.HexColor('#f87171')
        BLUE = colors.HexColor('#38bdf8')
        WHITE = colors.HexColor('#e2e4f0')
        MUTED = colors.HexColor('#5a6080')
        MUTED_2 = colors.HexColor('#7b82a8')
        BORDER = colors.HexColor('#1e2235')
        BORDER_2 = colors.HexColor('#252840')

        styles = getSampleStyleSheet()

        # Title style
        style_title = ParagraphStyle(
            'title', fontSize=24, textColor=WHITE,
            backColor=BG_MAIN, alignment=1, spaceAfter=8,
            fontName='Helvetica-Bold', leading=30
        )

        # Subtitle style
        style_subtitle = ParagraphStyle(
            'subtitle', fontSize=11, textColor=MUTED,
            backColor=BG_MAIN, alignment=1, spaceAfter=20,
            fontName='Helvetica', leading=14
        )

        # Section header with left accent
        style_h2 = ParagraphStyle(
            'h2', fontSize=13, textColor=WHITE,
            backColor=BG_CARD, alignment=0, spaceAfter=12, spaceBefore=20,
            fontName='Helvetica-Bold', leading=18,
            leftIndent=12,
            borderLeftWidth=3, borderLeftColor=INDIGO,
            borderRightWidth=0, borderTopWidth=0, borderBottomWidth=0,
            borderPadding=8
        )

        # Body text
        style_body = ParagraphStyle(
            'body', fontSize=10, textColor=MUTED_2,
            alignment=0, fontName='Helvetica', leading=14
        )

        story = []

        # ═══════════════════════════════════════════════════════════════════════
        # HEADER SECTION
        # ═══════════════════════════════════════════════════════════════════════
        story.append(Table(
            [['']],
            colWidths=[16 * cm],
            rowHeights=[3],
            style=TableStyle([
                ('BACKGROUND', (0, 0), (-1, -1), INDIGO),
            ])
        ))
        story.append(Spacer(1, 0.5 * cm))

        story.append(Paragraph(plain("Sales Analyzer"), style_title))
        story.append(Paragraph(
            plain(f"Premium Forecast Report — {datetime.datetime.now().strftime('%B %d, %Y at %H:%M')}"),
            style_subtitle
        ))

        story.append(Table(
            [['']],
            colWidths=[16 * cm],
            rowHeights=[1],
            style=TableStyle([
                ('BACKGROUND', (0, 0), (-1, -1), BORDER_2),
            ])
        ))
        story.append(Spacer(1, 0.3 * cm))

        # ═══════════════════════════════════════════════════════════════════════
        # KPI CARDS — 2x3 Grid
        # ═══════════════════════════════════════════════════════════════════════
        story.append(Paragraph(plain("Forecast Summary"), style_h2))

        kpi_cards = [
            ("Predicted Revenue", f"{result.get('revenue_pred', 0):,.0f} $", INDIGO, "Annual Forecast"),
            ("Predicted Profit", f"{result.get('profit_pred', 0):,.0f} $", GREEN, "Net Earnings"),
            ("Profit Margin", f"{result.get('profit_margin', 0):.1f}%", AMBER, "Efficiency"),
            ("Model Accuracy", f"R² = {result.get('metrics', {}).get('revenue', {}).get('r2', 0):.4f}", BLUE,
             "Confidence"),
            ("RMSE", f"{result.get('metrics', {}).get('revenue', {}).get('rmse', 0):,.0f}", MUTED, "Error Margin"),
            ("CV Score", f"{result.get('metrics', {}).get('revenue', {}).get('cv_r2', 0):.4f}", INDIGO_GLOW,
             "Stability"),
        ]

        # Build card content
        def make_card(label, value, color, sub):
            card_data = [
                [Paragraph(plain(label),
                           ParagraphStyle('cl', fontSize=9, textColor=MUTED, fontName='Helvetica', leading=12))],
                [Paragraph(plain(value),
                           ParagraphStyle('cv', fontSize=16, textColor=color, fontName='Helvetica-Bold', leading=20,
                                          alignment=1))],
                [Paragraph(plain(sub),
                           ParagraphStyle('cs', fontSize=8, textColor=MUTED_2, fontName='Helvetica', leading=10,
                                          alignment=1))]
            ]
            t = Table(card_data, colWidths=[6.5 * cm])
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, -1), BG_CARD),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('TOPPADDING', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, -1), (-1, -1), 10),
                ('LEFTPADDING', (0, 0), (-1, -1), 8),
                ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                ('BOX', (0, 0), (-1, -1), 1, BORDER),
            ]))
            return t

        kpi_grid_data = []
        for i in range(0, len(kpi_cards), 2):
            row = []
            for j in range(2):
                if i + j < len(kpi_cards):
                    label, value, color, sub = kpi_cards[i + j]
                    row.append(make_card(label, value, color, sub))
                else:
                    row.append('')
            kpi_grid_data.append(row)

        kpi_grid = Table(kpi_grid_data, colWidths=[7.5 * cm, 7.5 * cm])
        kpi_grid.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('LEFTPADDING', (0, 0), (-1, -1), 6),
            ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(kpi_grid)
        story.append(Spacer(1, 0.5 * cm))

        # ═══════════════════════════════════════════════════════════════════════
        # MONTHLY FORECAST
        # ═══════════════════════════════════════════════════════════════════════
        monthly = result.get('monthly_forecast', [])
        if monthly:
            story.append(Paragraph(plain("Monthly Forecasts"), style_h2))

            monthly_data = [[
                Paragraph(plain("Month"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=1)),
                Paragraph(plain("Revenue"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=1)),
                Paragraph(plain("Profit"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=1)),
                Paragraph(plain("Margin"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=1)),
            ]]

            for m in monthly:
                monthly_data.append([
                    Paragraph(plain(m.get('month_label', '')),
                              ParagraphStyle('td', fontSize=10, textColor=WHITE, fontName='Helvetica', alignment=1)),
                    Paragraph(plain(f"{m.get('revenue', 0):,.0f}"),
                              ParagraphStyle('td', fontSize=10, textColor=INDIGO, fontName='Helvetica-Bold',
                                             alignment=1)),
                    Paragraph(plain(f"{m.get('profit', 0):,.0f}"),
                              ParagraphStyle('td', fontSize=10, textColor=GREEN, fontName='Helvetica-Bold',
                                             alignment=1)),
                    Paragraph(plain(f"{m.get('margin', 0):.1f}%"),
                              ParagraphStyle('td', fontSize=10, textColor=AMBER, fontName='Helvetica-Bold',
                                             alignment=1)),
                ])

            m_table = Table(monthly_data, colWidths=[4 * cm, 5 * cm, 5 * cm, 3 * cm])
            m_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), BG_HEADER),
                ('BACKGROUND', (0, 1), (-1, -1), BG_CARD),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [BG_CARD, BG_CARD_2]),
                ('GRID', (0, 0), (-1, -1), 0.5, BORDER),
                ('BOX', (0, 0), (-1, -1), 1, BORDER_2),
                ('TOPPADDING', (0, 0), (-1, 0), 8),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('TOPPADDING', (0, 1), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ]))
            story.append(m_table)
            story.append(Spacer(1, 0.5 * cm))

        # ═══════════════════════════════════════════════════════════════════════
        # PRODUCT PERFORMANCE
        # ═══════════════════════════════════════════════════════════════════════
        products = result.get('products_summary', [])
        if products:
            story.append(Paragraph(plain("Product Performance"), style_h2))

            prod_data = [[
                Paragraph(plain("Product"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=0)),
                Paragraph(plain("Revenue"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=1)),
                Paragraph(plain("Profit"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=1)),
                Paragraph(plain("Rating"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=1)),
            ]]

            for p in products:
                label = p.get('label', '')
                label_color = GREEN if label == 'Top' else AMBER if label == 'Average' else RED

                prod_data.append([
                    Paragraph(plain(p.get('name', '').title()),
                              ParagraphStyle('td', fontSize=10, textColor=WHITE, fontName='Helvetica-Bold',
                                             alignment=0)),
                    Paragraph(plain(f"{p.get('revenue', 0):,.0f}"),
                              ParagraphStyle('td', fontSize=10, textColor=WHITE, fontName='Helvetica', alignment=1)),
                    Paragraph(plain(f"{p.get('profit', 0):,.0f}"),
                              ParagraphStyle('td', fontSize=10, textColor=WHITE, fontName='Helvetica', alignment=1)),
                    Paragraph(plain(label),
                              ParagraphStyle('td', fontSize=10, textColor=label_color, fontName='Helvetica-Bold',
                                             alignment=1)),
                ])

            p_table = Table(prod_data, colWidths=[5 * cm, 5 * cm, 5 * cm, 3 * cm])
            p_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), BG_HEADER),
                ('BACKGROUND', (0, 1), (-1, -1), BG_CARD),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [BG_CARD, BG_CARD_2]),
                ('GRID', (0, 0), (-1, -1), 0.5, BORDER),
                ('BOX', (0, 0), (-1, -1), 1, BORDER_2),
                ('TOPPADDING', (0, 0), (-1, 0), 8),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('TOPPADDING', (0, 1), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
                ('LEFTPADDING', (0, 0), (0, -1), 12),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ]))
            story.append(p_table)
            story.append(Spacer(1, 0.5 * cm))

        # ═══════════════════════════════════════════════════════════════════════
        # WHAT-IF SCENARIOS
        # ═══════════════════════════════════════════════════════════════════════
        what_if = result.get('what_if_scenarios', [])
        if what_if:
            story.append(Paragraph(plain("What-If Scenario Analysis"), style_h2))

            whatif_data = [[
                Paragraph(plain("Scenario"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=0)),
                Paragraph(plain("Revenue"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=1)),
                Paragraph(plain("Profit"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=1)),
                Paragraph(plain("Change"),
                          ParagraphStyle('th', fontSize=9, textColor=MUTED, fontName='Helvetica-Bold', alignment=1)),
            ]]

            for sc in what_if:
                change = sc.get('change_pct', 0)
                change_str = f"+{change}%" if change > 0 else f"{change}%"
                change_color = GREEN if change > 0 else RED if change < 0 else MUTED

                whatif_data.append([
                    Paragraph(plain(sc.get('name', '')),
                              ParagraphStyle('td', fontSize=10, textColor=WHITE, fontName='Helvetica-Bold',
                                             alignment=0)),
                    Paragraph(plain(f"{sc.get('revenue', 0):,.0f}"),
                              ParagraphStyle('td', fontSize=10, textColor=INDIGO, fontName='Helvetica-Bold',
                                             alignment=1)),
                    Paragraph(plain(f"{sc.get('profit', 0):,.0f}"),
                              ParagraphStyle('td', fontSize=10, textColor=GREEN, fontName='Helvetica-Bold',
                                             alignment=1)),
                    Paragraph(plain(change_str),
                              ParagraphStyle('td', fontSize=10, textColor=change_color, fontName='Helvetica-Bold',
                                             alignment=1)),
                ])

            w_table = Table(whatif_data, colWidths=[5 * cm, 5 * cm, 5 * cm, 3 * cm])
            w_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), BG_HEADER),
                ('BACKGROUND', (0, 1), (-1, -1), BG_CARD),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [BG_CARD, BG_CARD_2]),
                ('GRID', (0, 0), (-1, -1), 0.5, BORDER),
                ('BOX', (0, 0), (-1, -1), 1, BORDER_2),
                ('TOPPADDING', (0, 0), (-1, 0), 8),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('TOPPADDING', (0, 1), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
                ('LEFTPADDING', (0, 0), (0, -1), 12),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ]))
            story.append(w_table)

        # ═══════════════════════════════════════════════════════════════════════
        # FOOTER
        # ═══════════════════════════════════════════════════════════════════════
        story.append(Spacer(1, 1 * cm))
        story.append(Table(
            [['']],
            colWidths=[16 * cm],
            rowHeights=[1],
            style=TableStyle([
                ('BACKGROUND', (0, 0), (-1, -1), BORDER_2),
            ])
        ))
        story.append(Spacer(1, 0.3 * cm))
        story.append(Paragraph(
            plain("Generated by Sales Analyzer — Advanced ML Forecasting Engine"),
            ParagraphStyle('footer', fontSize=8, textColor=MUTED, alignment=1, fontName='Helvetica')
        ))

        doc.build(story)
        output.seek(0)

        filename = f"sales_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
        return send_file(
            output,
            mimetype='application/pdf',
            as_attachment=True,
            download_name=filename
        )

    except ImportError:
        flash('Install required library: pip install reportlab', 'error')
        return redirect(url_for('dashboard'))
    except Exception as e:
        import traceback
        traceback.print_exc()
        flash(f'Error creating PDF: {str(e)}', 'error')
        return redirect(url_for('dashboard'))


# ==============================================
# Error Handlers
# ==============================================

@app.errorhandler(413)
def file_too_large(e):
    flash('File too large (max 16MB allowed)', 'error')
    return redirect(url_for('upload'))


@app.errorhandler(404)
def not_found(e):
    return (
        "<h2 style='font-family:sans-serif;color:#6366f1;text-align:center;margin-top:5rem'>"
        "Sorry, this page does not exist!</h2>"
        "<p style='text-align:center'><a href='/'>Back to Home</a></p>"
    ), 404


@app.errorhandler(500)
def server_error(e):
    return (
        "<h2 style='font-family:sans-serif;color:#f87171;text-align:center;margin-top:5rem'>"
        "Internal Server Error</h2>"
        "<p style='text-align:center'><a href='/'>Back to Home</a></p>"
    ), 500


if __name__ == '__main__':
    app.run(debug=True)