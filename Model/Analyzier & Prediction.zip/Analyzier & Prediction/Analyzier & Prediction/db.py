import mysql.connector
from mysql.connector import Error
from config import Config

def get_connection():
    try:
        conn = mysql.connector.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            database=Config.DB_NAME
        )
        return conn
    except Error as e:
        print(f"[DB ERROR] فشل الاتصال: {e}")
        return None


def init_db():
    conn = get_connection()
    if not conn:
        return False
    cursor = conn.cursor()
    tables = [
        """
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL,
            email VARCHAR(150) UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at DATETIME DEFAULT NOW(),
            last_login DATETIME
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS uploads (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            filename VARCHAR(255),
            file_path TEXT,
            rows_count INT,
            cols_count INT,
            uploaded_at DATETIME DEFAULT NOW(),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS analysis_results (
            id INT AUTO_INCREMENT PRIMARY KEY,
            upload_id INT,
            forecast_period VARCHAR(50),
            predicted_revenue FLOAT,
            predicted_profit FLOAT,
            model_used VARCHAR(50),
            rmse_score FLOAT,
            mae_score FLOAT,
            r2_score FLOAT,
            insights_json LONGTEXT,
            created_at DATETIME DEFAULT NOW(),
            FOREIGN KEY (upload_id) REFERENCES uploads(id) ON DELETE CASCADE
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS products_summary (
            id INT AUTO_INCREMENT PRIMARY KEY,
            upload_id INT,
            product_name VARCHAR(200),
            total_revenue FLOAT,
            total_profit FLOAT,
            total_quantity INT,
            performance_label VARCHAR(20),
            FOREIGN KEY (upload_id) REFERENCES uploads(id) ON DELETE CASCADE
        )
        """
    ]
    try:
        for table_sql in tables:
            cursor.execute(table_sql)
        conn.commit()
        print("[DB] ✅ كل الجداول اتعملت بنجاح")
        return True
    except Error as e:
        print(f"[DB ERROR] فشل إنشاء الجداول: {e}")
        return False
    finally:
        cursor.close()
        conn.close()


def create_user(username, email, password_hash):
    conn = get_connection()
    if not conn:
        return None
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)",
            (username, email, password_hash)
        )
        conn.commit()
        return cursor.lastrowid
    except Error as e:
        print(f"[DB ERROR] create_user: {e}")
        return None
    finally:
        cursor.close()
        conn.close()


def get_user_by_email(email):
    conn = get_connection()
    if not conn:
        return None
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        return cursor.fetchone()
    finally:
        cursor.close()
        conn.close()


def update_last_login(user_id):
    conn = get_connection()
    if not conn:
        return
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE users SET last_login = NOW() WHERE id = %s", (user_id,)
        )
        conn.commit()
    finally:
        cursor.close()
        conn.close()


def save_upload(user_id, filename, file_path, rows_count, cols_count):
    conn = get_connection()
    if not conn:
        return None
    cursor = conn.cursor()
    try:
        cursor.execute(
            """INSERT INTO uploads (user_id, filename, file_path, rows_count, cols_count)
               VALUES (%s, %s, %s, %s, %s)""",
            (user_id, filename, file_path, rows_count, cols_count)
        )
        conn.commit()
        return cursor.lastrowid
    except Error as e:
        print(f"[DB ERROR] save_upload: {e}")
        return None
    finally:
        cursor.close()
        conn.close()


def get_user_uploads(user_id):
    conn = get_connection()
    if not conn:
        return []
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute(
            "SELECT * FROM uploads WHERE user_id = %s ORDER BY uploaded_at DESC",
            (user_id,)
        )
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()


def save_analysis(upload_id, forecast_period, predicted_revenue,
                  predicted_profit, model_used, rmse, mae, r2, insights_json):
    conn = get_connection()
    if not conn:
        return None
    cursor = conn.cursor()
    try:
        cursor.execute(
            """INSERT INTO analysis_results
               (upload_id, forecast_period, predicted_revenue, predicted_profit,
                model_used, rmse_score, mae_score, r2_score, insights_json)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (upload_id, forecast_period, predicted_revenue, predicted_profit,
             model_used, rmse, mae, r2, insights_json)
        )
        conn.commit()
        return cursor.lastrowid
    except Error as e:
        print(f"[DB ERROR] save_analysis: {e}")
        return None
    finally:
        cursor.close()
        conn.close()


def get_latest_analysis(upload_id):
    conn = get_connection()
    if not conn:
        return None
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute(
            """SELECT * FROM analysis_results
               WHERE upload_id = %s ORDER BY created_at DESC LIMIT 1""",
            (upload_id,)
        )
        return cursor.fetchone()
    finally:
        cursor.close()
        conn.close()


def save_products_summary(upload_id, products_list):
    conn = get_connection()
    if not conn:
        return False
    cursor = conn.cursor()
    try:
        for p in products_list:
            cursor.execute(
                """INSERT INTO products_summary
                   (upload_id, product_name, total_revenue, total_profit,
                    total_quantity, performance_label)
                   VALUES (%s, %s, %s, %s, %s, %s)""",
                (upload_id, p['name'], p['revenue'], p['profit'],
                 p['quantity'], p['label'])
            )
        conn.commit()
        return True
    except Error as e:
        print(f"[DB ERROR] save_products_summary: {e}")
        return False
    finally:
        cursor.close()
        conn.close()