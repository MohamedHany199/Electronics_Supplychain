"""
file_handler.py — User file upload, validation, and preprocessing

Responsibilities:
1. Validate file type (CSV / Excel)
2. Validate file size
3. Read file and convert to DataFrame
4. Column Detection — automatically find important columns
5. Check for sufficient data for training
6. Save file to disk and register in DB
"""

import os
import re
import uuid
import pandas as pd
from werkzeug.utils import secure_filename
from config import Config
from db import save_upload


# ──────────────────────────────────────────────
# Columns the project looks for automatically
# Each key is the internal name used in code
# Each value is a list of possible names in the user's file
# ──────────────────────────────────────────────
COLUMN_ALIASES = {
    "order_date":  ["order date", "date", "orderdate", "order_date",
                    "sale date", "sales date"],

    "revenue":     ["revenue generated", "revenue", "total revenue", "total sales",
            "sales", "income", "amount"],

    "profit":      ["profit", "net profit", "profit generated", "earnings"],

    "cost":        ["cost", "cost of goods", "cogs", "unit cost", "total cost"],

    "quantity":     ["quantity", "qty", "units sold", "units", "quantity sold",
                "number of products sold", "number of products"],

    "product":     ["product", "product type", "product name", "item"],

    "category":    ["category", "cat", "segment", "product category"],

    "region":      ["region", "area", "zone", "territory", "location"],
}

# Minimum number of rows for training
MIN_ROWS = Config.MIN_ROWS_REQUIRED


# ══════════════════════════════════════════════
# Main function — called directly from app.py
# ══════════════════════════════════════════════
def handle_upload(file, user_id):
    """
    Receives a file from request.files and performs all validation and saving.

    Returns:
        dict: {
            "success": True/False,
            "error": "Error message" or None,
            "upload_id": int or None,
            "df": DataFrame or None,
            "column_map": dict or None,
            "stats": dict or None
        }
    """
    # ── Step 1: Check if file exists ──
    if not file or file.filename == '':
        return _fail("No file was uploaded")

    # ── Step 2: Validate extension ──
    filename = secure_filename(file.filename)
    ext = _get_extension(filename)
    if ext not in Config.ALLOWED_EXTENSIONS:
        return _fail(f"Unsupported file type ({ext}) — only CSV, XLSX, XLS are accepted")

    # ── Step 3: Read the file ──
    df, read_error = _read_file(file, ext)
    if read_error:
        return _fail(read_error)

    # ═══════════════════════════════════════════════════════════════════════
    # FIXED: Save original column count BEFORE any processing
    # ═══════════════════════════════════════════════════════════════════════
    original_columns_count = len(df.columns)

    # ── Step 4: Check row count ──
    if len(df) < MIN_ROWS:
        return _fail(
            f"File contains only {len(df)} rows — "
            f"Minimum required is {MIN_ROWS} rows for training"
        )

    # ── Step 5: Column Detection ──
    column_map = _detect_columns(df)
    missing = _check_required_columns(column_map)
    if missing:
        return _fail(
            f"Missing required columns: {', '.join(missing)}\n"
            f"Columns found in your file: {', '.join(df.columns.tolist())}"
        )

    # ── Step 6: Save file to disk ──
    saved_path, save_error = _save_file_to_disk(file, filename, ext)
    if save_error:
        return _fail(save_error)

    # ── Step 7: Register upload in database ──
    upload_id = save_upload(
        user_id=user_id,
        filename=filename,
        file_path=saved_path,
        rows_count=len(df),
        cols_count=original_columns_count  # ← استخدم العدد الأصلي
    )
    if not upload_id:
        return _fail("Failed to save file data to database")

    # ── Step 8: Basic statistics ──
    stats = _compute_basic_stats(df, column_map, original_columns_count)
    stats["filename"] = filename

    return {
        "success":    True,
        "error":      None,
        "upload_id":  upload_id,
        "df":         df,
        "column_map": column_map,
        "stats":      stats
    }


# ══════════════════════════════════════════════
# Read the file
# ══════════════════════════════════════════════
def _read_file(file, ext):
    """
    Attempts to read the file and returns (DataFrame, error_message).
    Success → (df, None)
    Failure → (None, "Error message")
    """
    try:
        file.seek(0)  # Reset to beginning in case part was read before

        if ext == 'csv':
            # Try different encodings
            for encoding in ['utf-8', 'utf-8-sig', 'cp1256', 'latin-1']:
                try:
                    file.seek(0)
                    df = pd.read_csv(file, encoding=encoding)
                    break
                except (UnicodeDecodeError, Exception):
                    continue
            else:
                return None, "Failed to read CSV file — check encoding"

        elif ext in ('xlsx', 'xls'):
            engine = 'openpyxl' if ext == 'xlsx' else 'xlrd'
            df = pd.read_excel(file, engine=engine)

        else:
            return None, "Unknown file type"

        # Clean column names (remove extra spaces)
        df.columns = df.columns.str.strip()

        # Remove completely empty rows
        df.dropna(how='all', inplace=True)
        df.reset_index(drop=True, inplace=True)

        return df, None

    except Exception as e:
        return None, f"Error reading file: {str(e)}"


# ══════════════════════════════════════════════
# Column Detection — the heart of file_handler
# ══════════════════════════════════════════════
def _detect_columns(df):
    """
    Searches for required columns in the user's file regardless of their names.

    Logic:
    - Converts to lowercase and removes underscores/spaces
    - Compares with all aliases for each column
    - If found → adds the actual name to column_map

    Returns:
        dict: {"order_date": "Order Date", "revenue": "Revenue generated", ...}
              The value is the original name in the DataFrame
    """
    # Normalize DataFrame column names
    col_normalized = {
        col: re.sub(r'[\s_\-]+', ' ', col.strip().lower())
        for col in df.columns
    }

    column_map = {}

    for internal_name, aliases in COLUMN_ALIASES.items():
        for original_col, normalized_col in col_normalized.items():
            if normalized_col in aliases:
                column_map[internal_name] = original_col
                break  # First match is enough

    return column_map


def _check_required_columns(column_map):
    """
    Checks for the presence of required columns.

    Required:
    - order_date: needed for time-based forecasting
    - revenue: the main target

    Returns:
        list: Missing columns (empty if everything is present)
    """
    required = ["order_date", "revenue"]
    missing = [col for col in required if col not in column_map]
    return missing


# ══════════════════════════════════════════════
# Save file to disk
# ══════════════════════════════════════════════
def _save_file_to_disk(file, original_filename, ext):
    """
    Saves the file with a unique name (UUID) to avoid name conflicts.

    Returns:
        (saved_path, error_message)
    """
    try:
        file.seek(0)

        # Unique name: uuid4 + original extension
        unique_name = f"{uuid.uuid4().hex}.{ext}"
        save_path = os.path.join(Config.UPLOAD_FOLDER, unique_name)

        file.save(save_path)
        return save_path, None

    except Exception as e:
        return None, f"Failed to save file: {str(e)}"


# ═══════════════════════════════════════════════════════════════════════
# FIXED: Quick initial statistics — uses original column count
# FIXED: Date Range as formatted string
# ═══════════════════════════════════════════════════════════════════════
def _compute_basic_stats(df, column_map, original_cols_count):
    """
    Calculates initial statistics shown to the user before full analysis.

    Returns:
        dict: File statistics
    """
    stats = {
        "filename":      None,
        "rows":          len(df),
        "cols":          original_cols_count,
        "missing_cells": int(df.isnull().sum().sum()),
        "missing_pct":   round(df.isnull().sum().sum() / df.size * 100, 2),
        "detected_cols": list(column_map.keys()),
        "date_range":    None,
        "total_revenue": None,
        "total_profit":  None,
        "products":      None,
        "categories":    None,
        "regions":       None,
    }

    if "order_date" in column_map:
        try:
            dates = pd.to_datetime(df[column_map["order_date"]], errors='coerce')
            valid_dates = dates.dropna()
            if len(valid_dates) > 0:
                min_date = valid_dates.min().strftime("%Y-%m-%d")
                max_date = valid_dates.max().strftime("%Y-%m-%d")
                stats["date_range"] = f"{min_date} → {max_date}"
        except Exception:
            pass

    if "revenue" in column_map:
        try:
            rev_col = pd.to_numeric(df[column_map["revenue"]], errors='coerce')
            stats["total_revenue"] = round(float(rev_col.sum()), 2)
        except Exception:
            pass

    if "profit" in column_map:
        try:
            profit_col = pd.to_numeric(df[column_map["profit"]], errors='coerce')
            stats["total_profit"] = round(float(profit_col.sum()), 2)
        except Exception:
            pass

    for key in ["product", "category", "region"]:
        if key in column_map:
            try:
                unique_vals = df[column_map[key]].dropna().unique().tolist()
                stats[f"{key}s"] = sorted([str(v) for v in unique_vals])
            except Exception:
                pass

    return stats

# ══════════════════════════════════════════════
# Helper — load file from disk
# ══════════════════════════════════════════════
def load_file_from_disk(file_path):
    """
    Used when analyzing a previously uploaded file from history.

    Returns:
        (df, column_map, error_message)
    """
    if not os.path.exists(file_path):
        return None, None, "File not found on server"

    ext = _get_extension(file_path)

    try:
        if ext == 'csv':
            for encoding in ['utf-8', 'utf-8-sig', 'cp1256', 'latin-1']:
                try:
                    df = pd.read_csv(file_path, encoding=encoding)
                    break
                except UnicodeDecodeError:
                    continue
            else:
                return None, None, "Failed to read file"
        else:
            engine = 'openpyxl' if ext == 'xlsx' else 'xlrd'
            df = pd.read_excel(file_path, engine=engine)

        df.columns = df.columns.str.strip()
        df.dropna(how='all', inplace=True)
        df.reset_index(drop=True, inplace=True)

        column_map = _detect_columns(df)
        return df, column_map, None

    except Exception as e:
        return None, None, f"Error loading file: {str(e)}"


# ══════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════
def _get_extension(filename):
    """Returns file extension without dot and in lowercase"""
    return filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''


def _fail(message):
    """Unified template for failure messages"""
    return {
        "success":    False,
        "error":      message,
        "upload_id":  None,
        "df":         None,
        "column_map": None,
        "stats":      None
    }


# ══════════════════════════════════════════════
# For direct testing: python file_handler.py
# ══════════════════════════════════════════════
if __name__ == "__main__":
    import sys

    # Simple simulation without Flask
    test_path = sys.argv[1] if len(sys.argv) > 1 else "data/cleaned_electronics_supplyChain.csv"

    if not os.path.exists(test_path):
        print(f"❌ File not found: {test_path}")
        sys.exit(1)

    print(f"📂 Testing file: {test_path}")

    ext = _get_extension(test_path)
    with open(test_path, 'rb') as f:
        class FakeFile:
            filename = test_path
            def __init__(self, f): self._f = f
            def seek(self, n): self._f.seek(n)
            def read(self, *a): return self._f.read(*a)

        fake = FakeFile(f)
        df, err = _read_file(fake, ext)

    if err:
        print(f"❌ Read error: {err}")
        sys.exit(1)

    print(f"✅ File read successfully — {len(df)} rows × {len(df.columns)} columns")

    col_map = _detect_columns(df)
    print(f"\n🔍 Detected columns:")
    for internal, original in col_map.items():
        print(f"   {internal:15} → '{original}'")

    missing = _check_required_columns(col_map)
    if missing:
        print(f"\n⚠️  Missing columns: {missing}")
    else:
        print(f"\n✅ All required columns found")

    # Test with original column count
    original_cols = len(df.columns)
    stats = _compute_basic_stats(df, col_map, original_cols)
    print(f"\n📊 Initial statistics:")
    for k, v in stats.items():
        if v is not None:
            print(f"   {k}: {v}")