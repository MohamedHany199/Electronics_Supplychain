from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.feature_selection import mutual_info_regression


@dataclass
class FeatureSelectionResult:
    selected_features: List[str]
    mutual_information: Dict[str, float]
    correlation_dropped: List[str]


def build_supervised_frame(series_df: pd.DataFrame, target_col: str) -> pd.DataFrame:
    if series_df.empty:
        return pd.DataFrame()

    df = series_df[["ds", target_col]].copy().sort_values("ds").reset_index(drop=True)
    s = df[target_col]
    month_index = np.arange(len(df))

    df["year"] = df["ds"].dt.year
    df["month"] = df["ds"].dt.month
    df["quarter"] = df["ds"].dt.quarter
    df["week"] = df["ds"].dt.isocalendar().week.astype(int)
    df["day"] = df["ds"].dt.day
    df["month_index"] = month_index
    df["time_trend"] = month_index
    df["time_since_start"] = month_index
    df["quarter_start"] = df["ds"].dt.is_quarter_start.astype(int)
    df["quarter_end"] = df["ds"].dt.is_quarter_end.astype(int)
    df["month_start"] = df["ds"].dt.is_month_start.astype(int)
    df["month_end"] = df["ds"].dt.is_month_end.astype(int)
    df["year_end"] = df["ds"].dt.is_year_end.astype(int)
    df["business_quarter"] = df["quarter"]
    df["month_sin"] = np.sin(2 * np.pi * df["month"] / 12)
    df["month_cos"] = np.cos(2 * np.pi * df["month"] / 12)
    df["quarter_sin"] = np.sin(2 * np.pi * df["quarter"] / 4)
    df["quarter_cos"] = np.cos(2 * np.pi * df["quarter"] / 4)

    for lag in [1, 2, 3, 6, 12]:
        df[f"lag_{lag}"] = s.shift(lag)

    shifted = s.shift(1)
    for window in [3, 6, 12]:
        rolling = shifted.rolling(window=window, min_periods=1)
        df[f"rolling_mean_{window}"] = rolling.mean()
        df[f"rolling_std_{window}"] = rolling.std().fillna(0.0)
        df[f"rolling_var_{window}"] = rolling.var().fillna(0.0)
        df[f"rolling_median_{window}"] = rolling.median()
        df[f"rolling_max_{window}"] = rolling.max()
        df[f"rolling_min_{window}"] = rolling.min()
        df[f"ema_{window}"] = shifted.ewm(span=window, adjust=False, min_periods=1).mean()

    expanding = shifted.expanding(min_periods=1)
    df["expanding_mean"] = expanding.mean()
    df["expanding_std"] = expanding.std().fillna(0.0)
    df["momentum"] = s.shift(1) - s.shift(2)
    df["growth_rate"] = s.shift(1).pct_change().replace([np.inf, -np.inf], np.nan)
    df["mom_growth"] = s.shift(1).pct_change(1).replace([np.inf, -np.inf], np.nan)
    df["yoy_growth"] = s.shift(1).pct_change(12).replace([np.inf, -np.inf], np.nan)
    df["volatility_3"] = shifted.pct_change().rolling(3, min_periods=1).std().fillna(0.0)
    df["volatility_6"] = shifted.pct_change().rolling(6, min_periods=1).std().fillna(0.0)
    df["holiday_indicator"] = df["month"].isin([11, 12]).astype(int)
    df["business_season_indicator"] = df["month"].isin([1, 7, 8, 10, 11, 12]).astype(int)

    return df


def build_feature_row(history_df: pd.DataFrame, target_col: str, next_ds: pd.Timestamp) -> Dict[str, float]:
    temp = pd.concat(
        [history_df[["ds", target_col]], pd.DataFrame({"ds": [next_ds], target_col: [np.nan]})],
        ignore_index=True,
    )
    frame = build_supervised_frame(temp, target_col)
    row = frame.iloc[-1].drop(labels=[target_col])
    return row.to_dict()


def select_features(train_frame: pd.DataFrame, target_col: str, max_features: int = 20) -> FeatureSelectionResult:
    features = [c for c in train_frame.columns if c not in {"ds", target_col}]
    frame = train_frame.dropna(subset=[target_col]).copy()
    X = frame[features].replace([np.inf, -np.inf], np.nan).ffill().bfill().fillna(0.0)
    y = frame[target_col].values

    if len(X) < 8:
        return FeatureSelectionResult(features, {c: 0.0 for c in features}, [])

    mi = mutual_info_regression(X, y, random_state=42)
    mi_map = {feature: float(score) for feature, score in zip(features, mi)}
    ranked = sorted(features, key=lambda col: mi_map.get(col, 0.0), reverse=True)

    corr_dropped: List[str] = []
    corr = X[ranked].corr().abs()
    chosen: List[str] = []
    for feature in ranked:
        keep = True
        for selected in chosen:
            if corr.loc[feature, selected] >= 0.95:
                corr_dropped.append(feature)
                keep = False
                break
        if keep:
            chosen.append(feature)
        if len(chosen) >= max_features:
            break

    protected = [c for c in ["month", "quarter", "month_sin", "month_cos", "lag_1", "lag_12"] if c in features and c not in chosen]
    chosen.extend(protected)
    chosen = list(dict.fromkeys(chosen))

    return FeatureSelectionResult(chosen, mi_map, corr_dropped)


def prepare_training_matrix(train_frame: pd.DataFrame, target_col: str, selected_features: List[str]) -> Tuple[pd.DataFrame, pd.Series]:
    data = train_frame.dropna(subset=[target_col]).copy()
    for feature in selected_features:
        if feature not in data.columns:
            data[feature] = 0.0
    X = data[selected_features].replace([np.inf, -np.inf], np.nan).ffill().bfill().fillna(0.0)
    y = data[target_col]
    return X, y
