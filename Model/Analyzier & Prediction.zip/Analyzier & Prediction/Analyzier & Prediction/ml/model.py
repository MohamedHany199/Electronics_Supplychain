from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Dict, List

import pandas as pd

from ml.forecasting_engine import SalesForecastingEngine


@dataclass
class LegacyTrainResult:
    success: bool
    error: str | None
    revenue_model: object | None
    profit_model: object | None
    metrics: Dict | None
    feature_importance: Dict | None
    feature_cols: List[str] | None


def train(df_processed: pd.DataFrame, feature_cols=None) -> Dict:
    if not {"ds", "revenue", "profit"}.issubset(df_processed.columns):
        raise ValueError("The refactored engine expects a monthly DataFrame with ds, revenue, and profit columns.")
    engine = SalesForecastingEngine(df_processed[["ds", "revenue", "profit"]].copy(), forecast_horizon=12)
    payload = engine.train()
    revenue_bundle = payload["revenue_bundle"]
    profit_bundle = payload["profit_bundle"]
    return asdict(
        LegacyTrainResult(
            success=True,
            error=None,
            revenue_model=revenue_bundle,
            profit_model=profit_bundle,
            metrics={
                "revenue_rmse": revenue_bundle.metrics["rmse"],
                "revenue_mae": revenue_bundle.metrics["mae"],
                "revenue_r2": revenue_bundle.metrics["r2"],
                "profit_rmse": profit_bundle.metrics["rmse"],
                "profit_mae": profit_bundle.metrics["mae"],
                "profit_r2": profit_bundle.metrics["r2"],
                "cv_r2_revenue": revenue_bundle.metrics["r2"],
                "cv_r2_profit": profit_bundle.metrics["r2"],
                "cv_std_revenue": 0.0,
            },
            feature_importance=payload.get("feature_importance", {}),
            feature_cols=list(payload.get("feature_importance", {}).keys()),
        )
    )


def predict_period(*args, **kwargs):
    raise NotImplementedError("predict_period was replaced by SalesForecastingEngine.train() and pipeline-managed recursive forecasting.")


def load_models():
    return None, None, None


def _extract_last_known_row(df, feature_cols):
    return {}


def _compute_averages(df):
    return {}
