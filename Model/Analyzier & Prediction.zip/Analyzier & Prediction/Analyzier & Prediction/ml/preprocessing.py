from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

from config import Config


ARABIC_TO_ENGLISH = {
    "الإيرادات": "revenue",
    "المبيعات": "revenue",
    "إجمالي المبيعات": "revenue",
    "الإيراد": "revenue",
    "الدخل": "revenue",
    "الربح": "profit",
    "صافي الربح": "profit",
    "الأرباح": "profit",
    "التكلفة": "cost",
    "الكمية": "quantity",
    "العدد": "quantity",
    "الوحدات": "quantity",
    "التاريخ": "order_date",
    "تاريخ الطلب": "order_date",
    "تاريخ البيع": "order_date",
    "المنتج": "product",
    "اسم المنتج": "product",
    "نوع المنتج": "product",
    "الفئة": "category",
    "التصنيف": "category",
    "القسم": "category",
    "المنطقة": "region",
    "المدينة": "region",
    "الفرع": "region",
}

NUMERIC_CANDIDATES = ["revenue", "profit", "cost", "quantity"]
DIMENSION_COLUMNS = ["product", "category", "region"]


@dataclass
class DataAudit:
    missing_by_column: Dict[str, int]
    duplicate_rows: int
    invalid_date_rows: int
    negative_revenue_rows: int
    negative_profit_rows: int
    negative_quantity_rows: int
    outlier_summary: Dict[str, int]
    distribution_shift: Dict[str, float]
    seasonality_strength: float
    trend_strength: float
    business_cycle_strength: float
    monthly_points: int
    date_start: str | None
    date_end: str | None
    target_variability: Dict[str, float]
    consistency_checks: Dict[str, int]

    def to_dict(self) -> Dict:
        return {
            "missing_by_column": self.missing_by_column,
            "duplicate_rows": self.duplicate_rows,
            "invalid_date_rows": self.invalid_date_rows,
            "negative_revenue_rows": self.negative_revenue_rows,
            "negative_profit_rows": self.negative_profit_rows,
            "negative_quantity_rows": self.negative_quantity_rows,
            "outlier_summary": self.outlier_summary,
            "distribution_shift": self.distribution_shift,
            "seasonality_strength": round(float(self.seasonality_strength), 4),
            "trend_strength": round(float(self.trend_strength), 4),
            "business_cycle_strength": round(float(self.business_cycle_strength), 4),
            "monthly_points": int(self.monthly_points),
            "date_start": self.date_start,
            "date_end": self.date_end,
            "target_variability": {k: round(float(v), 4) for k, v in self.target_variability.items()},
            "consistency_checks": {k: int(v) for k, v in self.consistency_checks.items()},
        }


def preprocess(df: pd.DataFrame, column_map: Dict[str, str]) -> Dict:
    try:
        raw_df = df.copy()
        raw_df = _normalize_text(raw_df)
        raw_df, column_map = _rename_columns(raw_df, column_map)
        raw_df = _translate_arabic_columns_and_values(raw_df)

        missing_by_column = raw_df.isna().sum().astype(int).to_dict()
        duplicate_rows = int(raw_df.duplicated().sum())
        raw_df = raw_df.drop_duplicates().reset_index(drop=True)

        raw_df, invalid_date_rows = _process_dates(raw_df)
        raw_df = _clean_numeric_columns(raw_df)
        raw_df = _ensure_profit_without_fake_logic(raw_df)
        raw_df = _clean_dimension_columns(raw_df)
        raw_df = _sanitize_invalid_values(raw_df)

        if "revenue" not in raw_df.columns:
            return _fail("Revenue column is required after preprocessing")
        if "profit" not in raw_df.columns:
            return _fail("Profit column is required after preprocessing")

        raw_df = raw_df.dropna(subset=["order_date", "revenue", "profit"]).copy()
        if len(raw_df) < Config.MIN_ROWS_REQUIRED:
            return _fail(f"Not enough valid rows after preprocessing ({len(raw_df)} rows)")

        negative_revenue_rows = int((raw_df["revenue"] < 0).sum()) if "revenue" in raw_df else 0
        negative_profit_rows = int((raw_df["profit"] < 0).sum()) if "profit" in raw_df else 0
        negative_quantity_rows = int((raw_df.get("quantity", pd.Series(dtype=float)) < 0).sum()) if "quantity" in raw_df else 0

        filtered_columns = [
            c for c in ["order_date", "revenue", "profit", "cost", "quantity", "product", "category", "region"] if c in raw_df.columns
        ]
        cleaned_df = raw_df[filtered_columns].copy().sort_values("order_date").reset_index(drop=True)
        cleaned_df["year"] = cleaned_df["order_date"].dt.year
        cleaned_df["month"] = cleaned_df["order_date"].dt.month
        cleaned_df["quarter"] = cleaned_df["order_date"].dt.quarter
        cleaned_df["order_month"] = cleaned_df["order_date"].values.astype("datetime64[M]")

        monthly_totals = build_monthly_totals(cleaned_df)
        outlier_summary = _detect_outliers(cleaned_df, monthly_totals)
        audit = _audit_monthly_series(
            cleaned_df=cleaned_df,
            monthly_totals=monthly_totals,
            missing_by_column=missing_by_column,
            duplicate_rows=duplicate_rows,
            invalid_date_rows=invalid_date_rows,
            negative_revenue_rows=negative_revenue_rows,
            negative_profit_rows=negative_profit_rows,
            negative_quantity_rows=negative_quantity_rows,
            outlier_summary=outlier_summary,
        )

        return {
            "success": True,
            "error": None,
            "df": cleaned_df,
            "df_processed": cleaned_df,
            "feature_cols": [],
            "encoders": {},
            "scaler": None,
            "stats": {
                "rows_after": len(cleaned_df),
                "monthly_points": len(monthly_totals.groupby("ds")),
                "regions": sorted(cleaned_df["region"].dropna().unique().tolist()) if "region" in cleaned_df else [],
            },
            "quality_report": audit.to_dict(),
            "insights": _build_preprocessing_insights(audit),
            "monthly_totals": monthly_totals,
            "data_audit": audit.to_dict(),
        }
    except Exception as exc:
        return _fail(f"Preprocessing error: {exc}")


def build_monthly_totals(df: pd.DataFrame) -> pd.DataFrame:
    dimensions = [c for c in ["region"] if c in df.columns]
    grouped = (
        df.groupby(["order_month", *dimensions], dropna=False)
        .agg(
            revenue=("revenue", "sum"),
            profit=("profit", "sum"),
            quantity=("quantity", "sum") if "quantity" in df.columns else ("revenue", "size"),
            order_count=("revenue", "size"),
        )
        .reset_index()
        .rename(columns={"order_month": "ds"})
        .sort_values(["ds", *dimensions])
        .reset_index(drop=True)
    )
    grouped["quantity"] = grouped["quantity"].fillna(0.0)
    return grouped


def _normalize_text(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].astype(str).str.strip()
        df[col] = df[col].replace({"": np.nan, "nan": np.nan, "None": np.nan})
    return df


def _translate_arabic_columns_and_values(df: pd.DataFrame) -> pd.DataFrame:
    rename_map = {}
    for col in df.columns:
        clean = str(col).strip()
        if clean in ARABIC_TO_ENGLISH:
            rename_map[col] = ARABIC_TO_ENGLISH[clean]
    if rename_map:
        df = df.rename(columns=rename_map)

    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].map(lambda v: ARABIC_TO_ENGLISH.get(v, v) if isinstance(v, str) else v)
    return df


def _rename_columns(df: pd.DataFrame, column_map: Dict[str, str]) -> Tuple[pd.DataFrame, Dict[str, str]]:
    rename_dict = {}
    for internal_name, original_name in column_map.items():
        if original_name in df.columns and original_name != internal_name:
            rename_dict[original_name] = internal_name
    if rename_dict:
        df = df.rename(columns=rename_dict)
    new_map = {key: key for key in column_map if key in df.columns}
    return df, new_map


def _process_dates(df: pd.DataFrame) -> Tuple[pd.DataFrame, int]:
    if "order_date" not in df.columns:
        raise ValueError("Date column not found")

    parsed = pd.to_datetime(df["order_date"], errors="coerce")
    invalid_rows = int(parsed.isna().sum())
    df = df.loc[parsed.notna()].copy()
    df["order_date"] = parsed.loc[parsed.notna()]
    min_date = pd.Timestamp("1990-01-01")
    max_date = pd.Timestamp.now().normalize() + pd.DateOffset(years=1)
    range_mask = (df["order_date"] >= min_date) & (df["order_date"] <= max_date)
    invalid_rows += int((~range_mask).sum())
    df = df.loc[range_mask].copy()
    return df.sort_values("order_date").reset_index(drop=True), invalid_rows


def _clean_numeric_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in NUMERIC_CANDIDATES:
        if col not in df.columns:
            continue
        cleaned = (
            df[col]
            .astype(str)
            .str.replace(r"[^0-9.\-]", "", regex=True)
            .replace({"": np.nan, "-": np.nan, ".": np.nan})
        )
        df[col] = pd.to_numeric(cleaned, errors="coerce")
    return df


def _ensure_profit_without_fake_logic(df: pd.DataFrame) -> pd.DataFrame:
    if "revenue" not in df.columns:
        raise ValueError("Revenue column is required")

    if "profit" not in df.columns:
        if "cost" in df.columns:
            df["profit"] = df["revenue"] - df["cost"]
        else:
            raise ValueError("Profit column is missing and cannot be derived without cost. Fake margin assumptions were intentionally removed.")
    else:
        if "cost" in df.columns:
            missing_profit = df["profit"].isna() & df["revenue"].notna() & df["cost"].notna()
            df.loc[missing_profit, "profit"] = df.loc[missing_profit, "revenue"] - df.loc[missing_profit, "cost"]

    if df["profit"].isna().any():
        fill_ratio = float(df["profit"].isna().mean())
        if fill_ratio <= 0.05:
            df = df.sort_values("order_date").copy()
            df["profit"] = df["profit"].ffill()
        
    return df


def _clean_dimension_columns(df: pd.DataFrame) -> pd.DataFrame:
    for col in DIMENSION_COLUMNS:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip().str.lower().replace({"nan": "unknown", "": "unknown"})
    return df


def _sanitize_invalid_values(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if "revenue" in df.columns:
        df = df[df["revenue"].notna()].copy()
        df = df[df["revenue"] >= 0].copy()
    if "quantity" in df.columns:
        df["quantity"] = df["quantity"].clip(lower=0)
    if "cost" in df.columns:
        df["cost"] = df["cost"].clip(lower=0)
    return df


def _detect_outliers(cleaned_df: pd.DataFrame, monthly_totals: pd.DataFrame) -> Dict[str, int]:
    summary: Dict[str, int] = {}
    for col in ["revenue", "profit", "quantity"]:
        if col in cleaned_df.columns:
            summary[f"row_{col}"] = _iqr_outlier_count(cleaned_df[col])
    overall_monthly = (
        monthly_totals.groupby("ds", as_index=False)[[c for c in ["revenue", "profit", "quantity", "order_count"] if c in monthly_totals.columns]]
        .sum()
        .sort_values("ds")
        .reset_index(drop=True)
    )
    for col in ["revenue", "profit", "quantity", "order_count"]:
        if col in overall_monthly.columns:
            summary[f"monthly_{col}"] = _iqr_outlier_count(overall_monthly[col])
    return summary


def _iqr_outlier_count(series: pd.Series) -> int:
    values = pd.to_numeric(series, errors="coerce").dropna()
    if len(values) < 8:
        return 0
    q1 = values.quantile(0.25)
    q3 = values.quantile(0.75)
    iqr = q3 - q1
    if iqr == 0:
        return 0
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    return int(((values < lower) | (values > upper)).sum())


def _audit_monthly_series(
    cleaned_df: pd.DataFrame,
    monthly_totals: pd.DataFrame,
    missing_by_column: Dict[str, int],
    duplicate_rows: int,
    invalid_date_rows: int,
    negative_revenue_rows: int,
    negative_profit_rows: int,
    negative_quantity_rows: int,
    outlier_summary: Dict[str, int],
) -> DataAudit:
    overall_monthly = (
        monthly_totals.groupby("ds", as_index=False)[[c for c in ["revenue", "profit", "quantity", "order_count"] if c in monthly_totals.columns]]
        .sum()
        .sort_values("ds")
        .reset_index(drop=True)
    )

    revenue = overall_monthly["revenue"] if "revenue" in overall_monthly else pd.Series(dtype=float)
    profit = overall_monthly["profit"] if "profit" in overall_monthly else pd.Series(dtype=float)
    months = np.arange(len(overall_monthly), dtype=float)

    split_idx = max(1, len(revenue) // 2)
    first_half = revenue.iloc[:split_idx]
    second_half = revenue.iloc[split_idx:]
    revenue_mean_shift = 0.0
    profit_mean_shift = 0.0
    if len(first_half) and len(second_half) and abs(first_half.mean()) > 1e-9:
        revenue_mean_shift = float((second_half.mean() - first_half.mean()) / first_half.mean())
    first_profit = profit.iloc[:split_idx]
    second_profit = profit.iloc[split_idx:]
    if len(first_profit) and len(second_profit) and abs(first_profit.mean()) > 1e-9:
        profit_mean_shift = float((second_profit.mean() - first_profit.mean()) / first_profit.mean())

    seasonality_strength = 0.0
    trend_strength = 0.0
    cycle_strength = 0.0
    if len(overall_monthly) >= 12:
        monthly_profile = overall_monthly.groupby(overall_monthly["ds"].dt.month)["revenue"].mean()
        seasonality_strength = float(monthly_profile.std() / max(overall_monthly["revenue"].mean(), 1e-9))
        if len(revenue) > 1 and np.nanstd(revenue) > 0:
            trend_strength = float(np.corrcoef(months, revenue.values)[0, 1])
        cycle_strength = float(revenue.autocorr(lag=12) or 0.0)

    target_variability = {
        "revenue_cv": float(revenue.std() / max(revenue.mean(), 1e-9)) if len(revenue) else 0.0,
        "profit_cv": float(profit.std() / max(abs(profit.mean()), 1e-9)) if len(profit) else 0.0,
    }
    consistency_checks = {
        "profit_gt_revenue_rows": int(((cleaned_df["profit"] > cleaned_df["revenue"]) & cleaned_df["revenue"].notna()).sum()) if {"profit", "revenue"}.issubset(cleaned_df.columns) else 0,
        "zero_revenue_positive_profit_rows": int(((cleaned_df["revenue"] == 0) & (cleaned_df["profit"] > 0)).sum()) if {"profit", "revenue"}.issubset(cleaned_df.columns) else 0,
        "missing_profit_rows_after_derivation": int(cleaned_df["profit"].isna().sum()) if "profit" in cleaned_df else 0,
    }

    return DataAudit(
        missing_by_column={k: int(v) for k, v in missing_by_column.items()},
        duplicate_rows=int(duplicate_rows),
        invalid_date_rows=int(invalid_date_rows),
        negative_revenue_rows=int(negative_revenue_rows),
        negative_profit_rows=int(negative_profit_rows),
        negative_quantity_rows=int(negative_quantity_rows),
        outlier_summary={k: int(v) for k, v in outlier_summary.items()},
        distribution_shift={
            "revenue_mean_shift": round(revenue_mean_shift, 4),
            "profit_mean_shift": round(profit_mean_shift, 4),
        },
        seasonality_strength=seasonality_strength,
        trend_strength=trend_strength,
        business_cycle_strength=cycle_strength,
        monthly_points=len(overall_monthly),
        date_start=overall_monthly["ds"].min().strftime("%Y-%m-%d") if len(overall_monthly) else None,
        date_end=overall_monthly["ds"].max().strftime("%Y-%m-%d") if len(overall_monthly) else None,
        target_variability=target_variability,
        consistency_checks=consistency_checks,
    )


def _build_preprocessing_insights(audit: DataAudit) -> List[str]:
    insights: List[str] = []
    if audit.monthly_points < 24:
        insights.append("Less than 24 monthly observations are available; forecast uncertainty will be elevated.")
    else:
        insights.append("Sufficient monthly history is available for seasonal monthly forecasting.")

    if audit.invalid_date_rows > 0:
        insights.append(f"{audit.invalid_date_rows} rows were removed because their dates were invalid or out of range.")

    if abs(audit.distribution_shift.get("revenue_mean_shift", 0.0)) >= 0.15:
        insights.append(
            f"Revenue distribution shifted materially between the early and recent halves of history ({audit.distribution_shift['revenue_mean_shift']:.1%})."
        )
    if abs(audit.seasonality_strength) >= 0.08:
        insights.append("Revenue shows measurable monthly seasonality and should be forecast with seasonal features.")
    if abs(audit.trend_strength) >= 0.20:
        insights.append("Revenue shows a visible long-term trend across the observed horizon.")
    if audit.outlier_summary.get("monthly_revenue", 0) > 0:
        insights.append(f"Detected {audit.outlier_summary['monthly_revenue']} monthly revenue outliers that should be reviewed, not hard-capped blindly.")
    if audit.consistency_checks.get("profit_gt_revenue_rows", 0) > 0:
        insights.append("Some rows have profit greater than revenue; verify whether cost accounting or sign conventions are correct.")
    return insights


def _fail(message: str) -> Dict:
    return {
        "success": False,
        "error": message,
        "df": None,
        "df_processed": None,
        "feature_cols": None,
        "encoders": None,
        "scaler": None,
        "stats": None,
        "quality_report": None,
        "insights": [],
        "monthly_totals": None,
        "data_audit": None,
    }
