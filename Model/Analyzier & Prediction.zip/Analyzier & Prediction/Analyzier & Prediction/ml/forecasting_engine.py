from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import joblib
import numpy as np
import optuna
import pandas as pd
import shap
from catboost import CatBoostRegressor
from lightgbm import LGBMRegressor
from prophet import Prophet
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import TimeSeriesSplit
from statsmodels.tsa.statespace.sarimax import SARIMAX
from xgboost import XGBRegressor

from config import Config
from ml.feature_engineering import (
    FeatureSelectionResult,
    build_feature_row,
    build_supervised_frame,
    prepare_training_matrix,
    select_features,
)


TREE_MODELS = {"xgboost", "lightgbm", "catboost", "random_forest", "extra_trees", "hist_gradient_boosting"}


@dataclass
class TargetBundle:
    target: str
    best_model_name: str
    best_model: object
    selected_features: List[str]
    metrics: Dict
    comparison: List[Dict]
    feature_importance: Dict[str, float]
    permutation_importance: Dict[str, float]
    shap_summary: Dict[str, float]
    shap_reasons: List[Dict]
    shap_dependence: List[Dict]
    residuals: List[float]
    optuna_best_params: Dict
    validation_predictions: List[Dict]
    train_metrics: Dict
    validation_metrics: Dict
    cross_validation_metrics: Dict
    backtesting_metrics: Dict


class SalesForecastingEngine:
    def __init__(self, series_df: pd.DataFrame, forecast_horizon: int = 12):
        self.series_df = series_df.sort_values("ds").reset_index(drop=True)
        self.forecast_horizon = forecast_horizon
        self.random_state = Config.RANDOM_STATE

    def train(self) -> Dict:
        bundle_path = self._cache_path()
        if bundle_path.exists():
            base_payload = joblib.load(bundle_path)
        else:
            revenue_bundle = self._train_target("revenue")
            profit_bundle = self._train_target("profit")
            base_payload = {
                "success": True,
                "revenue_bundle": revenue_bundle,
                "profit_bundle": profit_bundle,
                "comparison": {
                    "revenue": revenue_bundle.comparison,
                    "profit": profit_bundle.comparison,
                },
                "feature_importance": revenue_bundle.feature_importance,
                "explainability": {
                    "revenue_shap_summary": revenue_bundle.shap_summary,
                    "profit_shap_summary": profit_bundle.shap_summary,
                    "revenue_reasons": revenue_bundle.shap_reasons,
                    "profit_reasons": profit_bundle.shap_reasons,
                    "revenue_dependence": revenue_bundle.shap_dependence,
                    "profit_dependence": profit_bundle.shap_dependence,
                },
            }
            joblib.dump(base_payload, bundle_path)

        revenue_bundle = base_payload["revenue_bundle"]
        profit_bundle = base_payload["profit_bundle"]
        revenue_forecast = self._forecast_target(revenue_bundle)
        profit_forecast = self._forecast_target(profit_bundle)
        combined_forecast = self._combine_forecasts(revenue_forecast, profit_forecast)

        payload = {
            **base_payload,
            "monthly_forecast": combined_forecast["monthly_forecast"],
            "confidence_interval": combined_forecast["confidence_interval"],
            "target_forecasts": {
                "revenue": {
                    "point": revenue_forecast["point"].to_dict("records"),
                    "interval": revenue_forecast["interval"],
                },
                "profit": {
                    "point": profit_forecast["point"].to_dict("records"),
                    "interval": profit_forecast["interval"],
                },
            },
        }
        return payload

    def _train_target(self, target: str) -> TargetBundle:
        series = self.series_df[["ds", target]].copy().sort_values("ds").reset_index(drop=True)
        frame = build_supervised_frame(series, target).replace([np.inf, -np.inf], np.nan)

        comparison: List[Dict] = []
        for model_name in [
            "xgboost",
            "lightgbm",
            "catboost",
            "random_forest",
            "extra_trees",
            "hist_gradient_boosting",
            "prophet",
            "sarimax",
        ]:
            comparison.append(self._backtest_model(series, target, model_name))

        optuna_best_params = self._optimize_xgboost(series, target)
        tuned_xgb_metrics = self._backtest_model(series, target, "xgboost", optuna_best_params)
        tuned_xgb_metrics["model_name"] = "xgboost_tuned"
        comparison.append(tuned_xgb_metrics)
        comparison = sorted(comparison, key=lambda row: (row.get("smape", 10**9), -row.get("r2", -10**9)))
        best = comparison[0]
        best_model_name = best["model_name"]

        train_series, validation_series, test_series = self._train_validation_test_split(series)
        validation_metrics = self._evaluate_holdout(train_series, validation_series, target, best_model_name, optuna_best_params)
        holdout_history = pd.concat([train_series, validation_series], ignore_index=True)
        backtesting_metrics = self._evaluate_holdout(holdout_history, test_series, target, best_model_name, optuna_best_params)
        train_metrics = self._in_sample_training_metrics(train_series, target, best_model_name, optuna_best_params)
        cross_validation_metrics = {
            k: v
            for k, v in best.items()
            if k not in {"predictions", "model_name"}
        }
        cross_validation_metrics["folds"] = self._summarize_fold_metrics(best.get("predictions", []))

        final_feature_selection = select_features(frame.dropna(subset=[target]), target, max_features=24)
        best_model = self._fit_final_model(series, frame, target, best_model_name, final_feature_selection, optuna_best_params)

        feature_importance, permutation_scores, shap_summary, shap_reasons, shap_dependence = self._explain_model(
            best_model_name,
            best_model,
            frame,
            target,
            final_feature_selection,
        )

        validation_predictions = best.get("predictions", [])
        residuals = [p["actual"] - p["predicted"] for p in validation_predictions if not math.isnan(p["predicted"])]
        metrics_summary = {
            "r2": best.get("r2", 0.0),
            "rmse": best.get("rmse", 0.0),
            "mae": best.get("mae", 0.0),
            "mape": best.get("mape", 0.0),
            "smape": best.get("smape", 0.0),
            "train": train_metrics,
            "validation": validation_metrics,
            "cross_validation": cross_validation_metrics,
            "backtesting": backtesting_metrics,
        }

        return TargetBundle(
            target=target,
            best_model_name=best_model_name,
            best_model=best_model,
            selected_features=final_feature_selection.selected_features,
            metrics=metrics_summary,
            comparison=comparison,
            feature_importance=feature_importance,
            permutation_importance=permutation_scores,
            shap_summary=shap_summary,
            shap_reasons=shap_reasons,
            shap_dependence=shap_dependence,
            residuals=residuals,
            optuna_best_params=optuna_best_params,
            validation_predictions=validation_predictions,
            train_metrics=train_metrics,
            validation_metrics=validation_metrics,
            cross_validation_metrics=cross_validation_metrics,
            backtesting_metrics=backtesting_metrics,
        )

    def _fit_final_model(
        self,
        series: pd.DataFrame,
        frame: pd.DataFrame,
        target: str,
        model_name: str,
        selection: FeatureSelectionResult,
        optuna_best_params: Dict,
    ):
        if model_name in {"prophet", "sarimax"}:
            return self._fit_stat_model(series, target, model_name)

        clean_frame = frame.dropna(subset=[target]).copy()
        X, y = prepare_training_matrix(clean_frame, target, selection.selected_features)
        params = optuna_best_params if model_name.startswith("xgboost") else None
        return self._fit_tree_model(model_name.replace("_tuned", ""), X, y, params=params)

    def _forecast_target(self, bundle: TargetBundle) -> Dict:
        series = self.series_df[["ds", bundle.target]].copy()
        if bundle.best_model_name in {"prophet", "sarimax"}:
            point = self._forecast_stat_model(series, bundle.best_model_name, bundle.best_model, self.forecast_horizon)
        else:
            point = self._forecast_tree_model(series, bundle.target, bundle.best_model, bundle.selected_features, self.forecast_horizon)

        interval = self._bootstrap_intervals(point, bundle.residuals)
        return {"point": point, "interval": interval}

    def _combine_forecasts(self, revenue_forecast: Dict, profit_forecast: Dict) -> Dict:
        rev_df = revenue_forecast["point"].rename(columns={"prediction": "revenue"})
        pro_df = profit_forecast["point"].rename(columns={"prediction": "profit"})
        merged = rev_df.merge(pro_df, on="ds", how="inner")
        merged["margin"] = np.where(merged["revenue"] > 0, merged["profit"] / merged["revenue"] * 100, 0.0)
        merged["month"] = merged["ds"].dt.month
        merged["month_label"] = merged["ds"].dt.strftime("%B %Y")

        monthly_forecast = [
            {
                "ds": row.ds.strftime("%Y-%m-%d"),
                "month": int(row.month),
                "month_label": row.month_label,
                "revenue": round(float(row.revenue), 2),
                "profit": round(float(row.profit), 2),
                "margin": round(float(row.margin), 2),
            }
            for row in merged.itertuples(index=False)
        ]

        revenue_percentiles = _aggregate_percentiles(revenue_forecast["interval"])
        profit_percentiles = _aggregate_percentiles(profit_forecast["interval"])
        confidence_interval = {
            "revenue": {
                "predicted": round(float(merged["revenue"].sum()), 2),
                "lower": round(float(revenue_percentiles[5]), 2),
                "upper": round(float(revenue_percentiles[95]), 2),
                "percentiles": {str(k): round(float(v), 2) for k, v in revenue_percentiles.items()},
            },
            "profit": {
                "predicted": round(float(merged["profit"].sum()), 2),
                "lower": round(float(profit_percentiles[5]), 2),
                "upper": round(float(profit_percentiles[95]), 2),
                "percentiles": {str(k): round(float(v), 2) for k, v in profit_percentiles.items()},
            },
            "confidence_level": _confidence_level(revenue_percentiles, merged["revenue"].sum()),
            "confidence_pct": _confidence_pct(revenue_percentiles, merged["revenue"].sum()),
            "interpretation": "Prediction intervals are derived from walk-forward residual bootstrapping rather than fixed growth rules.",
        }
        return {"monthly_forecast": monthly_forecast, "confidence_interval": confidence_interval}

    def _backtest_model(
        self,
        series: pd.DataFrame,
        target: str,
        model_name: str,
        custom_params: Dict | None = None,
    ) -> Dict:
        predictions: List[Dict] = []
        folds = self._folds(len(series))
        try:
            for fold_id, (train_idx, test_idx) in enumerate(folds, start=1):
                history = series.iloc[train_idx].copy().reset_index(drop=True)
                test = series.iloc[test_idx].copy().reset_index(drop=True)
                preds_df = self._fit_and_forecast(history, test, target, model_name, custom_params)
                merged = test.merge(preds_df.rename(columns={"prediction": "predicted"}), on="ds", how="left")
                for row in merged.itertuples(index=False):
                    predictions.append(
                        {
                            "fold": fold_id,
                            "ds": row.ds.strftime("%Y-%m-%d"),
                            "actual": float(getattr(row, target)),
                            "predicted": float(getattr(row, "predicted")),
                        }
                    )

            actual = np.array([p["actual"] for p in predictions], dtype=float)
            predicted = np.array([p["predicted"] for p in predictions], dtype=float)
            metrics = _metric_dict(actual, predicted)
            metrics.update({"model_name": model_name, "predictions": predictions})
            return metrics
        except Exception:
            return {
                "model_name": model_name,
                "r2": -999.0,
                "rmse": 10**12,
                "mae": 10**12,
                "mape": 10**12,
                "smape": 10**12,
                "predictions": [],
            }

    def _fit_and_forecast(
        self,
        history: pd.DataFrame,
        future: pd.DataFrame,
        target: str,
        model_name: str,
        custom_params: Dict | None = None,
    ) -> pd.DataFrame:
        horizon = len(future)
        if horizon == 0:
            return pd.DataFrame(columns=["ds", "prediction"])

        if model_name in {"prophet", "sarimax"}:
            fitted = self._fit_stat_model(history, target, model_name)
            return self._forecast_stat_model(history, model_name, fitted, horizon)

        train_frame = build_supervised_frame(history, target)
        selection = select_features(train_frame.dropna(subset=[target]), target, max_features=18)
        X_train, y_train = prepare_training_matrix(train_frame, target, selection.selected_features)
        X_fit, y_fit, X_val, y_val = self._tail_validation_split(X_train, y_train)
        params = custom_params if model_name.startswith("xgboost") else None
        model = self._fit_tree_model(model_name.replace("_tuned", ""), X_fit, y_fit, X_val, y_val, params=params)
        return self._forecast_tree_model(history, target, model, selection.selected_features, horizon)

    def _fit_tree_model(
        self,
        model_name: str,
        X: pd.DataFrame,
        y: pd.Series,
        X_val: pd.DataFrame | None = None,
        y_val: pd.Series | None = None,
        params: Dict | None = None,
    ):
        params = params or {}
        if model_name == "xgboost":
            model = XGBRegressor(
                n_estimators=params.get("n_estimators", 350),
                max_depth=params.get("max_depth", 4),
                learning_rate=params.get("learning_rate", 0.03),
                subsample=params.get("subsample", 0.85),
                colsample_bytree=params.get("colsample_bytree", 0.85),
                gamma=params.get("gamma", 0.0),
                min_child_weight=params.get("min_child_weight", 1.0),
                reg_alpha=params.get("reg_alpha", 0.0),
                reg_lambda=params.get("reg_lambda", 1.0),
                random_state=self.random_state,
                n_jobs=-1,
                early_stopping_rounds=25 if X_val is not None and len(X_val) > 0 else None,
            )
            fit_kwargs = {}
            if X_val is not None and len(X_val) > 0:
                fit_kwargs["eval_set"] = [(X_val, y_val)]
                fit_kwargs["verbose"] = False
            model.fit(X, y, **fit_kwargs)
            return model

        if model_name == "lightgbm":
            model = LGBMRegressor(
                n_estimators=300,
                learning_rate=0.04,
                num_leaves=31,
                subsample=0.9,
                colsample_bytree=0.9,
                min_child_samples=1,
                random_state=self.random_state,
                verbose=-1,
            )
            fit_kwargs = {}
            if X_val is not None and len(X_val) > 0:
                fit_kwargs["eval_set"] = [(X_val, y_val)]
                fit_kwargs["eval_metric"] = "l2"
            model.fit(X, y, **fit_kwargs)
            return model

        if model_name == "catboost":
            model = CatBoostRegressor(
                iterations=300,
                depth=5,
                learning_rate=0.04,
                loss_function="RMSE",
                random_state=self.random_state,
                verbose=False,
            )
            fit_kwargs = {}
            if X_val is not None and len(X_val) > 0:
                fit_kwargs["eval_set"] = (X_val, y_val)
                fit_kwargs["use_best_model"] = True
            model.fit(X, y, **fit_kwargs)
            return model

        if model_name == "random_forest":
            model = RandomForestRegressor(n_estimators=300, max_depth=6, random_state=self.random_state, n_jobs=-1)
        elif model_name == "extra_trees":
            model = ExtraTreesRegressor(n_estimators=300, max_depth=6, random_state=self.random_state, n_jobs=-1)
        elif model_name == "hist_gradient_boosting":
            model = HistGradientBoostingRegressor(max_depth=4, learning_rate=0.04, max_iter=300, random_state=self.random_state)
        else:
            raise ValueError(f"Unsupported tree model: {model_name}")
        model.fit(X, y)
        return model

    def _forecast_tree_model(self, history: pd.DataFrame, target: str, model, selected_features: List[str], horizon: int) -> pd.DataFrame:
        history = history.copy().sort_values("ds").reset_index(drop=True)
        preds: List[Dict] = []
        for _ in range(horizon):
            next_ds = history["ds"].max() + pd.offsets.MonthBegin(1)
            row = build_feature_row(history, target, next_ds)
            X_next = pd.DataFrame([{feature: row.get(feature, 0.0) for feature in selected_features}]).replace([np.inf, -np.inf], np.nan).fillna(0.0)
            pred = float(model.predict(X_next)[0])
            preds.append({"ds": next_ds, "prediction": max(pred, 0.0)})
            history = pd.concat([history, pd.DataFrame({"ds": [next_ds], target: [max(pred, 0.0)]})], ignore_index=True)
        return pd.DataFrame(preds)

    def _fit_stat_model(self, series: pd.DataFrame, target: str, model_name: str):
        if model_name == "prophet":
            model = Prophet(yearly_seasonality=True, weekly_seasonality=False, daily_seasonality=False, seasonality_mode="additive")
            model.fit(series.rename(columns={target: "y"})[["ds", "y"]])
            return model
        if model_name == "sarimax":
            model = SARIMAX(
                series[target],
                order=(1, 1, 1),
                seasonal_order=(1, 0, 0, 12),
                enforce_stationarity=False,
                enforce_invertibility=False,
            )
            return model.fit(disp=False)
        raise ValueError(f"Unsupported statistical model: {model_name}")

    def _forecast_stat_model(self, history: pd.DataFrame, model_name: str, fitted_model, horizon: int) -> pd.DataFrame:
        if model_name == "prophet":
            future = fitted_model.make_future_dataframe(periods=horizon, freq="MS")
            forecast = fitted_model.predict(future).tail(horizon)
            return forecast[["ds", "yhat"]].rename(columns={"yhat": "prediction"})
        if model_name == "sarimax":
            forecast = fitted_model.get_forecast(steps=horizon).predicted_mean
            dates = pd.date_range(history["ds"].max() + pd.offsets.MonthBegin(1), periods=horizon, freq="MS")
            return pd.DataFrame({"ds": dates, "prediction": np.maximum(forecast.values, 0.0)})
        raise ValueError(f"Unsupported statistical model: {model_name}")

    def _optimize_xgboost(self, series: pd.DataFrame, target: str) -> Dict:
        trials = max(1, Config.OPTUNA_TRIALS)

        def objective(trial: optuna.Trial) -> float:
            params = {
                "n_estimators": trial.suggest_int("n_estimators", 120, 420),
                "max_depth": trial.suggest_int("max_depth", 2, 8),
                "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.2, log=True),
                "subsample": trial.suggest_float("subsample", 0.6, 1.0),
                "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0),
                "gamma": trial.suggest_float("gamma", 0.0, 5.0),
                "min_child_weight": trial.suggest_float("min_child_weight", 1.0, 10.0),
                "reg_alpha": trial.suggest_float("reg_alpha", 0.0, 5.0),
                "reg_lambda": trial.suggest_float("reg_lambda", 0.1, 10.0),
            }
            metrics = self._backtest_model(series, target, "xgboost", params)
            return metrics["smape"]

        study = optuna.create_study(direction="minimize")
        study.optimize(objective, n_trials=trials, show_progress_bar=False)
        return study.best_params

    def _evaluate_holdout(
        self,
        history: pd.DataFrame,
        future: pd.DataFrame,
        target: str,
        model_name: str,
        optuna_best_params: Dict,
    ) -> Dict:
        if future.empty:
            return {"r2": 0.0, "rmse": 0.0, "mae": 0.0, "mape": 0.0, "smape": 0.0, "predictions": []}
        preds = self._fit_and_forecast(history, future, target, model_name, optuna_best_params if model_name.startswith("xgboost") else None)
        merged = future.merge(preds.rename(columns={"prediction": "predicted"}), on="ds", how="left")
        actual = merged[target].to_numpy(dtype=float)
        predicted = merged["predicted"].to_numpy(dtype=float)
        metrics = _metric_dict(actual, predicted)
        metrics["predictions"] = [
            {
                "ds": row.ds.strftime("%Y-%m-%d"),
                "actual": float(getattr(row, target)),
                "predicted": float(row.predicted),
            }
            for row in merged.itertuples(index=False)
        ]
        return metrics

    def _in_sample_training_metrics(
        self,
        history: pd.DataFrame,
        target: str,
        model_name: str,
        optuna_best_params: Dict,
    ) -> Dict:
        if model_name in {"prophet", "sarimax"}:
            fitted = self._fit_stat_model(history, target, model_name)
            if model_name == "prophet":
                fitted_values = fitted.predict(history[["ds"]])["yhat"].to_numpy(dtype=float)
            else:
                fitted_values = np.maximum(fitted.fittedvalues, 0.0)
            metrics = _metric_dict(history[target].to_numpy(dtype=float), np.asarray(fitted_values, dtype=float))
            metrics["predictions"] = []
            return metrics

        frame = build_supervised_frame(history, target)
        selection = select_features(frame.dropna(subset=[target]), target, max_features=18)
        X_train, y_train = prepare_training_matrix(frame, target, selection.selected_features)
        X_fit, y_fit, X_val, y_val = self._tail_validation_split(X_train, y_train)
        params = optuna_best_params if model_name.startswith("xgboost") else None
        model = self._fit_tree_model(model_name.replace("_tuned", ""), X_fit, y_fit, X_val, y_val, params=params)
        preds = np.asarray(model.predict(X_train), dtype=float)
        metrics = _metric_dict(y_train.to_numpy(dtype=float), preds)
        metrics["predictions"] = []
        return metrics

    def _explain_model(
        self,
        model_name: str,
        model,
        frame: pd.DataFrame,
        target: str,
        selection: FeatureSelectionResult,
    ) -> Tuple[Dict[str, float], Dict[str, float], Dict[str, float], List[Dict], List[Dict]]:
        clean_frame = frame.dropna(subset=[target]).copy()
        if model_name not in TREE_MODELS and not model_name.startswith("xgboost_tuned"):
            baseline = {feature: round(float(selection.mutual_information.get(feature, 0.0)), 6) for feature in selection.selected_features[:12]}
            return baseline, baseline, baseline, [], []

        X, y = prepare_training_matrix(clean_frame, target, selection.selected_features)
        if len(X) == 0:
            return {}, {}, {}, [], []

        perm = permutation_importance(model, X, y, n_repeats=10, random_state=self.random_state)
        permutation_scores = {
            feature: round(float(score), 6)
            for feature, score in sorted(zip(selection.selected_features, perm.importances_mean), key=lambda pair: pair[1], reverse=True)
        }

        sample = X.tail(min(24, len(X)))
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(sample)
        if isinstance(shap_values, list):
            shap_values = shap_values[0]
        mean_abs = np.abs(shap_values).mean(axis=0)
        shap_summary = {
            feature: round(float(value), 6)
            for feature, value in sorted(zip(sample.columns.tolist(), mean_abs), key=lambda pair: pair[1], reverse=True)
        }
        feature_importance = _normalize_importance(shap_summary)

        last_row = sample.iloc[[-1]]
        last_shap = shap_values[-1]
        reasons: List[Dict] = []
        for feature, value in sorted(zip(sample.columns.tolist(), last_shap), key=lambda pair: abs(pair[1]), reverse=True)[:6]:
            reasons.append(
                {
                    "feature": feature,
                    "impact": round(float(value), 6),
                    "feature_value": round(float(last_row.iloc[0][feature]), 6),
                }
            )

        dependence: List[Dict] = []
        for feature in list(shap_summary.keys())[:5]:
            idx = sample.columns.get_loc(feature)
            dependence.append(
                {
                    "feature": feature,
                    "feature_values": [round(float(v), 6) for v in sample[feature].tolist()],
                    "shap_values": [round(float(v), 6) for v in shap_values[:, idx].tolist()],
                }
            )
        return feature_importance, permutation_scores, shap_summary, reasons, dependence

    def _bootstrap_intervals(self, point_forecast: pd.DataFrame, residuals: List[float], samples: int = 400) -> Dict:
        if not residuals:
            residuals = [0.0]
        rng = np.random.default_rng(self.random_state)
        matrix = []
        residuals_arr = np.array(residuals, dtype=float)
        for row_idx, pred in enumerate(point_forecast["prediction"].tolist(), start=1):
            scale = math.sqrt(max(1.0, row_idx / 3.0))
            draws = pred + rng.choice(residuals_arr, size=samples, replace=True) * scale
            draws = np.maximum(draws, 0.0)
            matrix.append(draws)
        matrix = np.array(matrix)
        return {int(q): np.quantile(matrix, q / 100.0, axis=1).tolist() for q in [5, 25, 50, 75, 95]}

    def _cache_path(self) -> Path:
        raw = self.series_df.to_csv(index=False).encode("utf-8")
        key_seed = f"{Config.CACHE_VERSION}|engine_v4|".encode("utf-8") + raw
        key = hashlib.sha256(key_seed).hexdigest()
        return Path(Config.CACHE_FOLDER) / f"forecast_bundle_{key}.joblib"

    def _folds(self, n_rows: int) -> List[Tuple[np.ndarray, np.ndarray]]:
        if n_rows < 18:
            split = max(6, n_rows - 3)
            return [(np.arange(split), np.arange(split, n_rows))]
        test_size = min(6, max(3, n_rows // 6))
        n_splits = min(4, max(2, (n_rows - test_size) // test_size))
        splitter = TimeSeriesSplit(n_splits=n_splits, test_size=test_size)
        return list(splitter.split(np.arange(n_rows)))

    def _train_validation_test_split(self, series: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        n = len(series)
        if n < 18:
            train_end = max(8, n - 6)
            val_end = max(train_end + 2, n - 3)
        else:
            train_end = max(12, int(n * 0.7))
            val_end = max(train_end + 3, int(n * 0.85))
        val_end = min(val_end, n - 1)
        train = series.iloc[:train_end].copy().reset_index(drop=True)
        validation = series.iloc[train_end:val_end].copy().reset_index(drop=True)
        test = series.iloc[val_end:].copy().reset_index(drop=True)
        if validation.empty and len(test) > 1:
            validation = test.iloc[:-1].copy().reset_index(drop=True)
            test = test.iloc[-1:].copy().reset_index(drop=True)
        return train, validation, test

    def _tail_validation_split(self, X: pd.DataFrame, y: pd.Series):
        if len(X) < 12:
            return X, y, None, None
        val_size = max(2, min(6, len(X) // 5))
        return X.iloc[:-val_size], y.iloc[:-val_size], X.iloc[-val_size:], y.iloc[-val_size:]

    def _summarize_fold_metrics(self, predictions: List[Dict]) -> List[Dict]:
        if not predictions:
            return []
        df = pd.DataFrame(predictions)
        rows: List[Dict] = []
        for fold, fold_df in df.groupby("fold"):
            rows.append({"fold": int(fold), **_metric_dict(fold_df["actual"].to_numpy(float), fold_df["predicted"].to_numpy(float))})
        return rows


def _metric_dict(actual: np.ndarray, predicted: np.ndarray) -> Dict[str, float]:
    actual = np.asarray(actual, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    ape = np.where(actual != 0, np.abs((actual - predicted) / actual), np.nan)
    smape = np.where((np.abs(actual) + np.abs(predicted)) == 0, 0.0, 2 * np.abs(predicted - actual) / (np.abs(actual) + np.abs(predicted)))
    return {
        "r2": round(float(r2_score(actual, predicted)), 4) if len(actual) > 1 else 0.0,
        "rmse": round(float(np.sqrt(mean_squared_error(actual, predicted))), 4),
        "mae": round(float(mean_absolute_error(actual, predicted)), 4),
        "mape": round(float(np.nanmean(ape) * 100), 4),
        "smape": round(float(np.nanmean(smape) * 100), 4),
    }


def _normalize_importance(score_map: Dict[str, float]) -> Dict[str, float]:
    if not score_map:
        return {}
    total = sum(max(v, 0.0) for v in score_map.values()) or 1.0
    return {k: round(max(v, 0.0) / total, 6) for k, v in score_map.items()}


def _aggregate_percentiles(interval_map: Dict) -> Dict[int, float]:
    return {int(q): float(np.sum(values)) for q, values in interval_map.items()}


def _confidence_level(percentiles: Dict[int, float], point_forecast_total: float) -> str:
    spread = (percentiles[95] - percentiles[5]) / max(point_forecast_total, 1e-9)
    if spread <= 0.15:
        return "High"
    if spread <= 0.30:
        return "Moderate"
    return "Low"


def _confidence_pct(percentiles: Dict[int, float], point_forecast_total: float) -> int:
    spread = (percentiles[95] - percentiles[5]) / max(point_forecast_total, 1e-9)
    return max(30, min(95, int(round((1 - min(spread, 1.0)) * 100))))
