from __future__ import annotations

import datetime as dt
import json
from typing import Dict, List

import numpy as np
import pandas as pd

from db import save_analysis, save_products_summary
from file_handler import handle_upload
from ml.forecasting_engine import SalesForecastingEngine
from ml.preprocessing import build_monthly_totals, preprocess


def run_pipeline(file, user_id, filters: dict) -> dict:
    result = {"success": False, "error": None}
    try:
        upload_result = handle_upload(file, user_id=user_id)
        if not upload_result["success"]:
            result["error"] = upload_result["error"]
            return result

        raw_df = upload_result["df"]
        column_map = upload_result["column_map"]
        upload_id = upload_result["upload_id"]
        stats = upload_result["stats"]

        prep_result = preprocess(raw_df, column_map)
        if not prep_result["success"]:
            result["error"] = prep_result["error"]
            return result

        cleaned_df = prep_result["df_processed"]
        forecast_year = _parse_forecast_year(filters)
        region = (filters.get("region") or "").strip().lower()

        scoped_df, filters_applied = _apply_filters(cleaned_df, region)
        if scoped_df["order_month"].nunique() < 18:
            result["error"] = "Filtered data has fewer than 18 monthly observations; broaden the scope or provide more history."
            return result

        monthly_series = _prepare_scope_series(scoped_df)
        forecast_horizon = _forecast_horizon_for_year(monthly_series, forecast_year)
        engine = SalesForecastingEngine(monthly_series, forecast_horizon=forecast_horizon)
        forecast_bundle = engine.train()
        if not forecast_bundle.get("success"):
            result["error"] = forecast_bundle.get("error", "Forecast engine failed")
            return result

        monthly_forecast, confidence_interval = _slice_forecast_year(
            forecast_bundle["target_forecasts"],
            forecast_year,
        )
        feature_importance = forecast_bundle["feature_importance"]
        explainability = forecast_bundle["explainability"]

        comparison = forecast_bundle["comparison"]
        revenue_best = forecast_bundle["revenue_bundle"]
        profit_best = forecast_bundle["profit_bundle"]

        revenue_pred = float(sum(item["revenue"] for item in monthly_forecast))
        profit_pred = float(sum(item["profit"] for item in monthly_forecast))
        profit_margin = round((profit_pred / revenue_pred) * 100, 2) if revenue_pred else 0.0

        metrics = _build_metrics(revenue_best, profit_best)
        eda_report = _build_eda_report(scoped_df, stats, prep_result["data_audit"])
        anomalies = _detect_anomalies(scoped_df)
        products_summary = _build_products_summary(scoped_df, revenue_pred, profit_pred)
        business_insights = _build_business_insights(monthly_forecast, metrics, products_summary, anomalies, explainability)
        what_if_scenarios = _build_what_if_from_intervals(confidence_interval)
        export_data = _build_export_data(monthly_forecast, products_summary, metrics, filters_applied)

        forecast_period_str = str(forecast_year)
        insights_json = json.dumps(
            {
                "filters": filters_applied,
                "comparison": comparison,
                "feature_importance": feature_importance,
                "monthly_forecast": monthly_forecast,
                "products_summary": products_summary,
                "business_insights": business_insights,
                "eda_report": eda_report,
                "anomalies": anomalies,
                "confidence_interval": confidence_interval,
                "explainability": explainability,
            },
            ensure_ascii=False,
            default=str,
        )

        save_analysis(
            upload_id=upload_id,
            forecast_period=forecast_period_str,
            predicted_revenue=revenue_pred,
            predicted_profit=profit_pred,
            model_used=f"Revenue={revenue_best.best_model_name}; Profit={profit_best.best_model_name}",
            rmse=metrics["revenue"]["rmse"],
            mae=metrics["revenue"]["mae"],
            r2=metrics["revenue"]["r2"],
            insights_json=insights_json,
        )
        if products_summary:
            save_products_summary(upload_id, products_summary)

        result.update(
            {
                "success": True,
                "upload_id": upload_id,
                "stats": {**stats, "filename": file.filename if file else None},
                "revenue_pred": round(revenue_pred, 2),
                "profit_pred": round(profit_pred, 2),
                "profit_margin": profit_margin,
                "metrics": metrics,
                "feature_importance": feature_importance,
                "monthly_forecast": monthly_forecast,
                "products_summary": products_summary,
                "filters_applied": {**filters_applied, "year": forecast_year, "year_note": "Forecast"},
                "forecast_year": forecast_year,
                "eda_report": eda_report,
                "business_insights": business_insights,
                "confidence_interval": confidence_interval,
                "anomalies": anomalies,
                "what_if_scenarios": what_if_scenarios,
                "export_data": export_data,
                "model_comparison": comparison,
                "explainability": explainability,
            }
        )
        return result
    except Exception as exc:
        result["error"] = f"Internal Pipeline Error: {exc}"
        return result


def _apply_filters(df: pd.DataFrame, region: str) -> tuple[pd.DataFrame, Dict]:
    scoped = df.copy()
    applied: Dict = {}
    if region and "region" in scoped.columns:
        scoped = scoped[scoped["region"].str.lower() == region].copy()
        applied["region"] = region
    return scoped.sort_values("order_date").reset_index(drop=True), applied


def _prepare_scope_series(scoped_df: pd.DataFrame) -> pd.DataFrame:
    monthly = (
        scoped_df.groupby("order_month", as_index=False)
        .agg(revenue=("revenue", "sum"), profit=("profit", "sum"), quantity=("quantity", "sum") if "quantity" in scoped_df.columns else ("revenue", "size"))
        .rename(columns={"order_month": "ds"})
        .sort_values("ds")
        .reset_index(drop=True)
    )
    monthly["quantity"] = monthly["quantity"].fillna(0.0)
    return monthly


def _build_metrics(revenue_bundle, profit_bundle) -> Dict:
    rev = revenue_bundle.metrics
    pro = profit_bundle.metrics
    return {
        "revenue": {
            "rmse": rev["backtesting"]["rmse"],
            "mae": rev["backtesting"]["mae"],
            "r2": rev["backtesting"]["r2"],
            "mape": rev["backtesting"]["mape"],
            "smape": rev["backtesting"]["smape"],
            "cv_r2": rev["cross_validation"]["r2"],
            "cv_std": round(float(np.std([row["actual"] - row["predicted"] for row in revenue_bundle.validation_predictions])) if revenue_bundle.validation_predictions else 0.0, 4),
            "train_metrics": revenue_bundle.train_metrics,
            "validation_metrics": revenue_bundle.validation_metrics,
            "cross_validation_metrics": revenue_bundle.cross_validation_metrics,
            "backtesting_metrics": revenue_bundle.backtesting_metrics,
        },
        "profit": {
            "rmse": pro["backtesting"]["rmse"],
            "mae": pro["backtesting"]["mae"],
            "r2": pro["backtesting"]["r2"],
            "mape": pro["backtesting"]["mape"],
            "smape": pro["backtesting"]["smape"],
            "cv_r2": pro["cross_validation"]["r2"],
            "cv_std": round(float(np.std([row["actual"] - row["predicted"] for row in profit_bundle.validation_predictions])) if profit_bundle.validation_predictions else 0.0, 4),
            "train_metrics": profit_bundle.train_metrics,
            "validation_metrics": profit_bundle.validation_metrics,
            "cross_validation_metrics": profit_bundle.cross_validation_metrics,
            "backtesting_metrics": profit_bundle.backtesting_metrics,
        },
    }


def _build_eda_report(scoped_df: pd.DataFrame, stats: Dict, audit: Dict) -> Dict:
    monthly = _prepare_scope_series(scoped_df)
    quality_score = max(0, int(100 - min(40, scoped_df.isna().sum().sum() / max(scoped_df.size, 1) * 100 * 3) - min(20, scoped_df.duplicated().sum() * 2)))
    top_months = (
        monthly.assign(month_label=monthly["ds"].dt.strftime("%B %Y"))
        .sort_values("revenue", ascending=False)
        .head(3)[["month_label", "revenue"]]
        .rename(columns={"revenue": "avg_revenue"})
        .to_dict("records")
    )
    seasonality = (
        monthly.groupby(monthly["ds"].dt.quarter)["revenue"].mean() / max(monthly["revenue"].mean(), 1e-9) * 100
    ).round(1).to_dict()
    seasonality = {f"Q{int(k)}": float(v) for k, v in seasonality.items()}
    return {
        "summary": {
            "total_rows": len(scoped_df),
            "total_cols": stats.get("cols", len(scoped_df.columns)),
            "date_range": f"{monthly['ds'].min().strftime('%Y-%m-%d')} → {monthly['ds'].max().strftime('%Y-%m-%d')}",
            "total_revenue": round(float(scoped_df["revenue"].sum()), 2),
            "total_profit": round(float(scoped_df["profit"].sum()), 2),
        },
        "insights": [
            f"Monthly history points: {audit.get('monthly_points', len(monthly))}",
            f"Seasonality strength: {audit.get('seasonality_strength', 0):.2f}",
            f"Trend strength: {audit.get('trend_strength', 0):.2f}",
        ],
        "data_quality": {
            "missing_cells": int(scoped_df.isna().sum().sum()),
            "missing_pct": round(float(scoped_df.isna().sum().sum() / max(scoped_df.size, 1) * 100), 2),
            "duplicate_rows": int(scoped_df.duplicated().sum()),
            "quality_score": quality_score,
        },
        "top_months": top_months,
        "seasonality": seasonality,
        "audit": audit,
    }


def _detect_anomalies(scoped_df: pd.DataFrame) -> List[Dict]:
    monthly = _prepare_scope_series(scoped_df)
    if len(monthly) < 6:
        return []
    q1 = monthly["revenue"].quantile(0.25)
    q3 = monthly["revenue"].quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    median_rev = monthly["revenue"].median()
    anomalies = []
    for row in monthly.itertuples(index=False):
        if row.revenue < lower or row.revenue > upper:
            deviation = abs(row.revenue - median_rev) / max(median_rev, 1e-9) * 100
            anomaly_type = "spike" if row.revenue > upper else "drop"
            anomalies.append(
                {
                    "year": int(row.ds.year),
                    "month": int(row.ds.month),
                    "month_label": row.ds.strftime("%B %Y"),
                    "revenue": round(float(row.revenue), 2),
                    "type": anomaly_type,
                    "deviation_pct": round(float(deviation), 1),
                    "message": f"{row.ds.strftime('%B %Y')} shows an unusual {anomaly_type} versus the historical monthly median.",
                }
            )
    return anomalies


def _build_products_summary(scoped_df: pd.DataFrame, forecast_revenue: float, forecast_profit: float) -> List[Dict]:
    if "product" not in scoped_df.columns:
        return []
    grouped = scoped_df.groupby("product", as_index=False).agg(revenue=("revenue", "sum"), profit=("profit", "sum"), quantity=("quantity", "sum") if "quantity" in scoped_df.columns else ("revenue", "size"))
    if grouped.empty:
        return []

    trailing_cutoff = scoped_df["order_date"].max() - pd.DateOffset(months=12)
    trailing = scoped_df[scoped_df["order_date"] >= trailing_cutoff].copy()
    trailing_mix = trailing.groupby("product", as_index=False).agg(revenue_recent=("revenue", "sum"), profit_recent=("profit", "sum"))
    grouped = grouped.merge(trailing_mix, on="product", how="left").fillna(0.0)
    grouped["allocation_base"] = grouped["revenue_recent"].where(grouped["revenue_recent"] > 0, grouped["revenue"])
    grouped["revenue_share"] = grouped["allocation_base"] / max(grouped["allocation_base"].sum(), 1e-9)
    grouped["profit_share"] = grouped["profit_recent"].where(grouped["profit_recent"] != 0, grouped["profit"]) / max(abs(grouped["profit_recent"].where(grouped["profit_recent"] != 0, grouped["profit"]).sum()), 1e-9)
    grouped["forecast_revenue"] = grouped["revenue_share"] * forecast_revenue
    grouped["forecast_profit"] = grouped["revenue_share"] * forecast_profit
    grouped["margin"] = np.where(grouped["forecast_revenue"] > 0, grouped["forecast_profit"] / grouped["forecast_revenue"] * 100, 0.0)
    grouped = grouped.sort_values("forecast_revenue", ascending=False).reset_index(drop=True)
    labels = []
    for idx in range(len(grouped)):
        if idx < max(1, len(grouped) // 3):
            labels.append("Top")
        elif idx < max(2, (2 * len(grouped)) // 3):
            labels.append("Average")
        else:
            labels.append("Low")
    grouped["label"] = labels
    return [
        {
            "name": row.product,
            "revenue": round(float(row.forecast_revenue), 2),
            "profit": round(float(row.forecast_profit), 2),
            "quantity": int(row.quantity),
            "profit_margin": round(float(row.margin), 2),
            "label": row.label,
        }
        for row in grouped.itertuples(index=False)
    ]


def _build_business_insights(monthly_forecast: List[Dict], metrics: Dict, products_summary: List[Dict], anomalies: List[Dict], explainability: Dict) -> List[Dict]:
    insights: List[Dict] = []
    revenue_metrics = metrics.get("revenue", {})
    profit_metrics = metrics.get("profit", {})
    annual_revenue = sum(item["revenue"] for item in monthly_forecast)
    annual_profit = sum(item["profit"] for item in monthly_forecast)
    margin = (annual_profit / annual_revenue * 100) if annual_revenue else 0

    insights.append({
        "icon": "📈",
        "type": "success" if revenue_metrics.get("r2", 0) >= 0.6 else "warning",
        "title": "Backtesting accuracy",
        "text": f"Revenue backtesting R² = {revenue_metrics.get('r2', 0):.3f}, SMAPE = {revenue_metrics.get('smape', 0):.2f}%.",
    })
    insights.append({
        "icon": "💰",
        "type": "success" if margin >= 25 else "warning",
        "title": "Profit margin dynamics",
        "text": f"Forecast annual profit margin is {margin:.2f}% and is derived from independent revenue and profit forecasts.",
    })
    if monthly_forecast:
        peak = max(monthly_forecast, key=lambda row: row["revenue"])
        trough = min(monthly_forecast, key=lambda row: row["revenue"])
        insights.append({
            "icon": "📅",
            "type": "info",
            "title": "Seasonal swing",
            "text": f"Peak forecast month is {peak['month_label']} and the softest month is {trough['month_label']}.",
        })
    if products_summary:
        top_product = products_summary[0]
        insights.append({
            "icon": "🏆",
            "type": "success",
            "title": f"Top product mix contributor: {top_product['name'].title()}",
            "text": f"Forecast allocation uses recent product mix share and assigns {top_product['revenue']:,.0f} revenue with margin {top_product['profit_margin']:.1f}%.",
        })
    for reason in explainability.get("revenue_reasons", [])[:2]:
        direction = "increased" if reason["impact"] >= 0 else "decreased"
        insights.append({
            "icon": "🧠",
            "type": "info",
            "title": f"Revenue {direction} due to {reason['feature']}",
            "text": f"Latest modeled feature value: {reason['feature_value']}, SHAP impact: {reason['impact']:+.4f}.",
        })
    if anomalies:
        insights.append({
            "icon": "🔍",
            "type": "warning",
            "title": f"Historical anomalies detected: {len(anomalies)}",
            "text": anomalies[0]["message"],
        })
    return insights[:8]


def _build_what_if_from_intervals(confidence_interval: Dict) -> List[Dict]:
    rev = confidence_interval.get("revenue", {})
    pro = confidence_interval.get("profit", {})
    rp = rev.get("percentiles", {})
    pp = pro.get("percentiles", {})
    base_rev = rev.get("predicted", 0)
    base_pro = pro.get("predicted", 0)
    optimistic_rev = rp.get("95", rev.get("upper", base_rev))
    optimistic_pro = pp.get("95", pro.get("upper", base_pro))
    conservative_rev = rp.get("5", rev.get("lower", base_rev))
    conservative_pro = pp.get("5", pro.get("lower", base_pro))
    return [
        {
            "name": "Optimistic Scenario",
            "icon": "🚀",
            "description": "95th percentile residual-bootstrap outcome",
            "revenue": round(float(optimistic_rev), 2),
            "profit": round(float(optimistic_pro), 2),
            "change_pct": round(((optimistic_rev - base_rev) / max(base_rev, 1e-9)) * 100, 1) if base_rev else 0,
            "color": "green",
        },
        {
            "name": "Baseline Scenario",
            "icon": "📊",
            "description": "Point forecast from the selected models",
            "revenue": round(float(base_rev), 2),
            "profit": round(float(base_pro), 2),
            "change_pct": 0,
            "color": "blue",
        },
        {
            "name": "Conservative Scenario",
            "icon": "🛡️",
            "description": "5th percentile residual-bootstrap outcome",
            "revenue": round(float(conservative_rev), 2),
            "profit": round(float(conservative_pro), 2),
            "change_pct": round(((conservative_rev - base_rev) / max(base_rev, 1e-9)) * 100, 1) if base_rev else 0,
            "color": "orange",
        },
    ]


def _build_export_data(monthly_forecast: List[Dict], products_summary: List[Dict], metrics: Dict, filters_applied: Dict) -> Dict:
    return {
        "monthly_table": [
            {
                "Month": row["month_label"],
                "Predicted Revenue": row["revenue"],
                "Predicted Profit": row["profit"],
                "Profit Margin %": row["margin"],
            }
            for row in monthly_forecast
        ],
        "products_table": [
            {
                "Product": row["name"].title(),
                "Revenue": row["revenue"],
                "Profit": row["profit"],
                "Quantity": row["quantity"],
                "Profit Margin %": row["profit_margin"],
                "Rating": row["label"],
            }
            for row in products_summary
        ],
        "pdf_summary": {
            "generated_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "filters": filters_applied,
            "revenue_r2": metrics.get("revenue", {}).get("r2", 0),
            "revenue_rmse": metrics.get("revenue", {}).get("rmse", 0),
            "revenue_mae": metrics.get("revenue", {}).get("mae", 0),
        },
        "ready": True,
    }


def _slice_forecast_year(target_forecasts: Dict, forecast_year: int) -> tuple[List[Dict], Dict]:
    rev_point = pd.DataFrame(target_forecasts["revenue"]["point"])
    pro_point = pd.DataFrame(target_forecasts["profit"]["point"])
    rev_point["ds"] = pd.to_datetime(rev_point["ds"])
    pro_point["ds"] = pd.to_datetime(pro_point["ds"])

    rev_slice = rev_point[rev_point["ds"].dt.year == forecast_year].reset_index(drop=True)
    pro_slice = pro_point[pro_point["ds"].dt.year == forecast_year].reset_index(drop=True)
    if rev_slice.empty or pro_slice.empty:
        rev_slice = rev_point.tail(12).reset_index(drop=True)
        pro_slice = pro_point.tail(12).reset_index(drop=True)

    monthly_forecast = []
    for rev_row, pro_row in zip(rev_slice.itertuples(index=False), pro_slice.itertuples(index=False)):
        revenue = float(rev_row.prediction)
        profit = float(pro_row.prediction)
        margin = (profit / revenue * 100) if revenue else 0.0
        monthly_forecast.append(
            {
                "ds": rev_row.ds.strftime("%Y-%m-%d"),
                "month": int(rev_row.ds.month),
                "month_label": rev_row.ds.strftime("%B %Y"),
                "revenue": round(revenue, 2),
                "profit": round(profit, 2),
                "margin": round(margin, 2),
            }
        )

    rev_interval = target_forecasts["revenue"]["interval"]
    pro_interval = target_forecasts["profit"]["interval"]
    offset = max(0, len(rev_point) - len(rev_slice))
    rev_percentiles = {int(k): float(np.sum(v[offset:offset + len(rev_slice)])) for k, v in rev_interval.items()}
    pro_percentiles = {int(k): float(np.sum(v[offset:offset + len(pro_slice)])) for k, v in pro_interval.items()}
    revenue_total = float(sum(item["revenue"] for item in monthly_forecast))
    profit_total = float(sum(item["profit"] for item in monthly_forecast))
    spread = (rev_percentiles[95] - rev_percentiles[5]) / max(revenue_total, 1e-9)
    confidence_level = "High" if spread <= 0.15 else "Moderate" if spread <= 0.30 else "Low"
    confidence_pct = max(30, min(95, int(round((1 - min(spread, 1.0)) * 100))))
    confidence_interval = {
        "revenue": {
            "predicted": round(revenue_total, 2),
            "lower": round(rev_percentiles[5], 2),
            "upper": round(rev_percentiles[95], 2),
            "percentiles": {str(k): round(v, 2) for k, v in rev_percentiles.items()},
        },
        "profit": {
            "predicted": round(profit_total, 2),
            "lower": round(pro_percentiles[5], 2),
            "upper": round(pro_percentiles[95], 2),
            "percentiles": {str(k): round(v, 2) for k, v in pro_percentiles.items()},
        },
        "confidence_level": confidence_level,
        "confidence_pct": confidence_pct,
        "interpretation": "Prediction intervals are derived from walk-forward residual bootstrapping instead of fixed growth assumptions.",
    }
    return monthly_forecast, confidence_interval


def _forecast_horizon_for_year(monthly_series: pd.DataFrame, forecast_year: int) -> int:
    last_ds = pd.to_datetime(monthly_series["ds"]).max()
    months_to_december = (forecast_year - last_ds.year) * 12 + (12 - last_ds.month)
    return max(12, int(months_to_december))


def _parse_forecast_year(filters: dict) -> int:
    year = (filters.get("year") or "").strip()
    if year:
        return int(year)
    return dt.datetime.now().year + 1
