from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from db import create_user, get_user_by_email, update_last_login

auth = Blueprint('auth', __name__)


@auth.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')

        if not username or not email or not password:
            flash('All fields are required', 'error')
            return render_template('login.html', mode='register')

        if len(password) < 6:
            flash('Password must be at least 6 characters', 'error')
            return render_template('login.html', mode='register')

        if password != confirm:
            flash('Passwords do not match', 'error')
            return render_template('login.html', mode='register')

        if get_user_by_email(email):
            flash('Email already registered', 'error')
            return render_template('login.html', mode='register')

        password_hash = generate_password_hash(password)
        user_id = create_user(username, email, password_hash)

        if user_id:
            session['user_id'] = user_id
            session['username'] = username
            flash('Account created successfully!', 'success')
            return redirect(url_for('upload'))
        else:
            flash('An error occurred, please try again', 'error')

    return render_template('login.html', mode='register')


@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not email or not password:
            flash('Enter email and password', 'error')
            return render_template('login.html', mode='login')

        user = get_user_by_email(email)

        if not user or not check_password_hash(user['password_hash'], password):
            flash('Invalid email or password', 'error')
            return render_template('login.html', mode='login')

        session['user_id'] = user['id']
        session['username'] = user['username']
        update_last_login(user['id'])

        flash(f'Welcome {user["username"]}!', 'success')
        return redirect(url_for('upload'))

    return render_template('login.html', mode='login')


@auth.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'info')
    return redirect(url_for('auth.login'))


def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login first', 'error')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated