import os
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-me")

    DB_HOST = os.environ.get("DB_HOST", "localhost")
    DB_USER = os.environ.get("DB_USER", "root")
    DB_PASSWORD = os.environ.get("DB_PASSWORD", "")
    DB_NAME = os.environ.get("DB_NAME", "sales_analyzer")

    UPLOAD_FOLDER = str(BASE_DIR / "uploads")
    MAX_CONTENT_LENGTH = int(os.environ.get("MAX_CONTENT_LENGTH", 16 * 1024 * 1024))
    ALLOWED_EXTENSIONS = {"csv", "xlsx", "xls"}

    DATA_FOLDER = str(BASE_DIR / "data")
    MODELS_FOLDER = str(BASE_DIR / "ml" / "trained_models")
    CACHE_FOLDER = str(BASE_DIR / "ml" / "cache")
    REPORTS_FOLDER = str(BASE_DIR / "data" / "reports")

    MIN_ROWS_REQUIRED = int(os.environ.get("MIN_ROWS_REQUIRED", 24))
    FORECAST_HORIZON_MONTHS = int(os.environ.get("FORECAST_HORIZON_MONTHS", 12))
    OPTUNA_TRIALS = int(os.environ.get("OPTUNA_TRIALS", 100))
    RANDOM_STATE = int(os.environ.get("RANDOM_STATE", 42))
    CACHE_VERSION = os.environ.get("CACHE_VERSION", "v3")


for folder in [
    Config.UPLOAD_FOLDER,
    Config.MODELS_FOLDER,
    Config.CACHE_FOLDER,
    Config.DATA_FOLDER,
    Config.REPORTS_FOLDER,
]:
    os.makedirs(folder, exist_ok=True)
